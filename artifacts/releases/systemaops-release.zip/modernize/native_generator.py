import re
import os
from decimal import Decimal

def to_java_var(name: str) -> str:
    # Check if name has subscript, e.g. ITEM-AMOUNT(3) or ITEM-AMOUNT ( WS-I )
    match = re.match(r'^([A-Za-z0-9_-]+)\s*\(\s*([^()]+)\s*\)$', name)
    if match:
        base = match.group(1).replace("-", "_").lower()
        idx = match.group(2).strip()
        idx_java = to_java_var(idx)
        if idx_java.isdigit():
            return f"{base}[{int(idx_java) - 1}]"
        return f"{base}[{idx_java} - 1]"

    name = name.replace("-", "_").lower()
    if name in ("class", "public", "private", "protected", "static", "final", "void", 
                "int", "double", "float", "long", "short", "char", "boolean", "byte", "new", "import", "package"):
        name = name + "_"
    return name

def to_java_method(name: str) -> str:
    parts = name.replace("-", "_").split("_")
    camel = "".join(p.capitalize() for p in parts if p)
    return "is" + camel


def is_input_file(logical: str, path: str) -> bool:
    logical_upper = logical.upper()
    path_lower = path.lower()
    if "IN-" in logical_upper or "SOURCE" in logical_upper or "SLS" in logical_upper or "INPUT" in logical_upper or "FILE-A" in logical_upper or "FILE-B" in logical_upper:
        return True
    if "OUT-" in logical_upper or "REPORT" in logical_upper or "RESULT" in logical_upper or "RPT" in logical_upper or "OUTPUT" in logical_upper:
        return False
    if "in" in path_lower or "source" in path_lower or "input" in path_lower:
        return True
    if "out" in path_lower or "report" in path_lower or "result" in path_lower:
        return False
    return True

def to_java_class(name: str) -> str:
    parts = name.replace("-", "_").split("_")
    return "".join(p.capitalize() for p in parts if p)

class NativeTypeMapper:
    @staticmethod
    def parse_pic(pic_str: str):
        pic = pic_str.upper()
        signed = pic.startswith("S")
        if signed:
            pic = pic[1:]
        
        expanded = []
        i = 0
        while i < len(pic):
            char = pic[i]
            if i + 1 < len(pic) and pic[i+1] == "(":
                end = pic.find(")", i + 1)
                if end != -1:
                    try:
                        count = int(pic[i+2:end])
                        expanded.append(char * count)
                    except ValueError:
                        expanded.append(char)
                    i = end + 1
                    continue
            expanded.append(char)
            i += 1
        
        expanded_str = "".join(expanded)
        if "X" in expanded_str or "Z" in expanded_str:
            return "String", len(expanded_str), 0, signed
        
        if "V" in expanded_str:
            parts = expanded_str.split("V")
            digits = parts[0].count("9") + parts[1].count("9")
            scale = parts[1].count("9")
            return "BigDecimal", digits, scale, signed
        else:
            digits = expanded_str.count("9")
            return "Integer" if digits <= 9 else "Long", digits, 0, signed

    @classmethod
    def get_java_type(cls, pic_str: str, usage: str = None) -> str:
        if usage and usage.upper() in ("COMP-3", "PACKED-DECIMAL"):
            return "BigDecimal"
        
        t_name, _, _, _ = cls.parse_pic(pic_str)
        return t_name

class LayoutNode:
    def __init__(self, name, level, parent=None):
        self.name = name
        self.level = level
        self.parent = parent
        self.children = []
        self.pic = None
        self.usage = None
        self.occurs = None
        self.occurs_min = None
        self.occurs_max = None
        self.depending_on = None
        self.redefines = None
        self.offset = 0
        self.length = 0
        self.occurs_list = []

class NativeExpressionTranslator:
    def __init__(self, variables_types: dict, redefines_layout: dict = None, occurs_depending_on: dict = None):
        self.var_types = variables_types
        self.redefines_layout = redefines_layout or {}
        self.occurs_depending_on = occurs_depending_on or {}

    def _translate_subscripts(self, expr: str) -> str:
        pattern = r'(?<![A-Za-z0-9_-])([A-Za-z0-9_-]+)\s*\(\s*([^()]+)\s*\)'
        def repl(match):
            cobol_name = match.group(1).upper()
            if cobol_name not in self.var_types and cobol_name not in self.redefines_layout and cobol_name not in self.occurs_depending_on:
                return match.group(0)
            var_name = to_java_var(cobol_name)
            idx = match.group(2).strip()
            for v in self.var_types.keys():
                idx = re.sub(r'\b' + re.escape(v) + r'\b', to_java_var(v), idx)
                
            for v in self.redefines_layout.keys():
                if not self.redefines_layout[v]["is_array"]:
                    idx = re.sub(r'\b' + re.escape(to_java_var(v)) + r'\b', f"get_{to_java_var(v)}()", idx)
            
            if cobol_name in self.occurs_depending_on:
                dep_var, min_val, max_val = self.occurs_depending_on[cobol_name]
                dep_java = to_java_var(dep_var)
                if dep_var in self.redefines_layout:
                    dep_val_expr = f"get_{dep_java}()"
                else:
                    dep_val_expr = dep_java
                subscript_expr = f"checkBounds({idx}, {min_val}, \"{dep_java}\", {dep_val_expr})"
            else:
                subscript_expr = idx
                
            if cobol_name in self.redefines_layout:
                return f"get_{var_name}({subscript_expr})"
            else:
                if cobol_name in self.occurs_depending_on:
                    return f"{var_name}[{subscript_expr}]"
                else:
                    if idx.isdigit():
                        return f"{var_name}[{int(idx) - 1}]"
                    return f"{var_name}[{idx} - 1]"
        
        old = ""
        while old != expr:
            old = expr
            expr = re.sub(pattern, repl, expr)
        return expr

    def translate(self, expr_str: str) -> str:
        expr_str = self._translate_subscripts(expr_str)
        
        # Protect array subscript expressions from being split by operator tokenizer.
        # Replace [...] content with placeholders, restore after tokenizing.
        placeholders = {}
        def _mask(m):
            key = f"\x00BR{len(placeholders)}\x00"
            placeholders[key] = m.group(1)
            return "[" + key + "]"
        masked = re.sub(r'\[([^\[\]]*)\]', _mask, expr_str)
        
        tokens = re.split(r'(\s+[\+\-\*\/]\s+|\(|\))', masked)
        
        translated_tokens = []
        for t in tokens:
            t_strip = t.strip()
            if not t_strip:
                continue
            if t_strip in ("+", "-", "*", "/", "(", ")"):
                translated_tokens.append(t_strip)
            elif re.match(r'^\d+(\.\d+)?$', t_strip):
                translated_tokens.append(f"new BigDecimal(\"{t_strip}\")")
            else:
                # Restore any masked bracket contents for the raw token output
                raw_token = t_strip
                for ph, orig in placeholders.items():
                    raw_token = raw_token.replace(f"[{ph}]", f"[{orig}]")
                
                if "[" in raw_token:
                    base_java = re.split(r'\[', raw_token)[0].strip()
                    v_type = "BigDecimal"
                    for cobol_var, c_type in self.var_types.items():
                        if to_java_var(cobol_var) == base_java:
                            v_type = c_type
                            break
                    if v_type in ("Integer", "Long"):
                        translated_tokens.append(f"BigDecimal.valueOf({raw_token})")
                    else:
                        translated_tokens.append(raw_token)
                elif raw_token.startswith("get_"):
                    translated_tokens.append(raw_token)
                else:
                    java_var = to_java_var(raw_token)
                    if raw_token.upper() in self.redefines_layout:
                        java_var = f"get_{java_var}()"
                    v_type = self.var_types.get(raw_token.upper(), "BigDecimal")
                    if v_type in ("Integer", "Long"):
                        translated_tokens.append(f"BigDecimal.valueOf({java_var})")
                    else:
                        translated_tokens.append(java_var)

        return self._convert_to_bigdecimal_calls(translated_tokens)

    def _convert_to_bigdecimal_calls(self, tokens: list) -> str:
        if not tokens:
            return "BigDecimal.ZERO"
        if len(tokens) == 1:
            return tokens[0]

        try:
            return self._parse_infix(tokens)
        except Exception:
            return "BigDecimal.ZERO"

    def _parse_infix(self, tokens: list) -> str:
        idx = 0
        def peek():
            nonlocal idx
            return tokens[idx] if idx < len(tokens) else None
        
        def consume():
            nonlocal idx
            val = peek()
            idx += 1
            return val
        
        def parse_factor() -> str:
            t = peek()
            if t == "(":
                consume()
                expr = parse_expr()
                consume()
                return expr
            return consume()

        def parse_term() -> str:
            left = parse_factor()
            while peek() in ("*", "/"):
                op = consume()
                right = parse_factor()
                if op == "*":
                    left = f"{left}.multiply({right})"
                else:
                    left = f"{left}.divide({right}, 2, RoundingMode.DOWN)"
            return left

        def parse_expr() -> str:
            left = parse_term()
            while peek() in ("+", "-"):
                op = consume()
                right = parse_term()
                if op == "+":
                    left = f"{left}.add({right})"
                else:
                    left = f"{left}.subtract({right})"
            return left

        return parse_expr()

class NativeStatementTranslator:
    def __init__(self, var_types: dict, file_assigns: list = None, record_to_fd: dict = None, all_generators: dict = None, current_generator = None, level88_map: dict = None):
        self.var_types = var_types
        self.file_assigns = file_assigns or []
        self.record_to_fd = record_to_fd or {}
        self.all_generators = all_generators or {}
        self.current_generator = current_generator
        self.level88_map = level88_map or {}
        self.redefines_layout = getattr(current_generator, "redefines_layout", {}) if current_generator else {}
        
        redefs = self.redefines_layout
        odos = getattr(current_generator, "occurs_depending_on", {}) if current_generator else {}
        self.expr_trans = NativeExpressionTranslator(var_types, redefines_layout=redefs, occurs_depending_on=odos)
        self.evaluate_count = 0
        self.evaluate_subject = None   # set when EVALUATE node is seen
        self.call_counter = 0

    def _is_variable(self, name: str) -> bool:
        base = re.split(r'\(', name)[0].strip()
        return base in self.var_types

    def _get_matched_fd(self, tgt) -> str:
        matched_fd = self.record_to_fd.get(tgt)
        if not matched_fd:
            for assign in self.file_assigns:
                logical = assign.get("logical_name", "")
                if logical.replace("-FILE", "") in tgt or tgt.replace("-REC", "") in logical:
                    matched_fd = logical
                    break
        if not matched_fd:
            matched_fd = tgt
        return matched_fd

    def _get_var_type(self, name: str, default: str = "String") -> str:
        base = re.split(r'\(', name)[0].strip()
        return self.var_types.get(base, default)

    def translate_math_operand(self, val: str, tgt_type: str) -> str:
        if re.match(r'^\d+(\.\d+)?$', val):
            return f"new BigDecimal(\"{val}\")" if tgt_type == "BigDecimal" else val
        expr = self.expr_trans.translate(val)
        if tgt_type in ("Integer", "Long"):
            if expr.startswith("BigDecimal.valueOf(") and expr.endswith(")"):
                return expr[19:-1]
        return expr

    def generate_assignment(self, tgt: str, value_expr: str) -> str:
        match = re.match(r'^([A-Za-z0-9_-]+)\s*\(\s*([^()]+)\s*\)$', tgt)
        if match:
            base = match.group(1).upper()
            idx = match.group(2).strip()
            
            if self.current_generator:
                for v in self.current_generator.var_types.keys():
                    idx = re.sub(r'\b' + re.escape(v) + r'\b', to_java_var(v), idx)
                    
            if self.current_generator:
                for v in self.current_generator.redefines_layout.keys():
                    if not self.current_generator.redefines_layout[v]["is_array"]:
                        idx = re.sub(r'\b' + re.escape(to_java_var(v)) + r'\b', f"get_{to_java_var(v)}()", idx)
            
            java_base = to_java_var(base)
            
            if self.current_generator:
                base_type = self.current_generator.var_types.get(base)
                if base_type == "String":
                    pic = self.current_generator.var_pics.get(base, "")
                    if pic:
                        _, length, _, _ = NativeTypeMapper.parse_pic(pic)
                        value_expr = f"padString(String.valueOf({value_expr}), {length})"
            
            if self.current_generator and base in self.current_generator.redefines_layout:
                layout = self.current_generator.redefines_layout[base]
                if base in self.current_generator.occurs_depending_on:
                    dep_var, min_val, max_val = self.current_generator.occurs_depending_on[base]
                    dep_java = to_java_var(dep_var)
                    if dep_var in self.current_generator.redefines_layout:
                        dep_val_expr = f"get_{dep_java}()"
                    else:
                        dep_val_expr = dep_java
                    subscript_expr = f"checkBounds({idx}, {min_val}, \"{dep_java}\", {dep_val_expr})"
                else:
                    subscript_expr = idx
                return f"set_{java_base}({subscript_expr}, {value_expr});"
            else:
                if self.current_generator and base in self.current_generator.occurs_depending_on:
                    dep_var, min_val, max_val = self.current_generator.occurs_depending_on[base]
                    dep_java = to_java_var(dep_var)
                    if dep_var in self.current_generator.redefines_layout:
                        dep_val_expr = f"get_{dep_java}()"
                    else:
                        dep_val_expr = dep_java
                    subscript_expr = f"checkBounds({idx}, {min_val}, \"{dep_java}\", {dep_val_expr})"
                else:
                    if idx.isdigit():
                        subscript_expr = f"{int(idx) - 1}"
                    else:
                        subscript_expr = f"{idx} - 1"
                return f"{java_base}[{subscript_expr}] = {value_expr};"
        else:
            base = tgt.upper()
            java_base = to_java_var(base)
            
            if self.current_generator:
                base_type = self.current_generator.var_types.get(base)
                if base_type == "String":
                    pic = self.current_generator.var_pics.get(base, "")
                    if pic:
                        _, length, _, _ = NativeTypeMapper.parse_pic(pic)
                        value_expr = f"padString(String.valueOf({value_expr}), {length})"
            
            if self.current_generator and base in self.current_generator.redefines_layout:
                return f"set_{java_base}({value_expr});"
            else:
                return f"{java_base} = {value_expr};"

    def translate_statement(self, node) -> str:
        props = node.properties if hasattr(node, "properties") else node.get("properties", {})
        stype = props.get("statement_type", "").upper()
        
        java_stmt = self._translate_statement_inner(node)
        if java_stmt is None:
            return None
        if not java_stmt:
            return ""
            
        if self.current_generator is None:
            return java_stmt
            
        cleaned = java_stmt.strip()
        if cleaned.endswith("{") or cleaned.endswith("}") or java_stmt.startswith("//"):
            return java_stmt
            
        lines = java_stmt.splitlines()
        if len(lines) == 1:
            return f"if (!skipToNextSentence) {{ {java_stmt} }}"
        else:
            indented = "\n            ".join(lines)
            return f"if (!skipToNextSentence) {{\n            {indented}\n        }}"

    def wrap_math_with_size_error(self, tgt, val_expr, props, tgt_type, val_is_bigdecimal=True):
        on_size_nodes = props.get("on_size_error_nodes", [])
        not_size_nodes = props.get("not_on_size_error_nodes", [])
        
        if not on_size_nodes and not not_size_nodes:
            if tgt_type == "Integer":
                final_expr = f"({val_expr}).intValue()" if val_is_bigdecimal else val_expr
            elif tgt_type == "Long":
                final_expr = f"({val_expr}).longValue()" if val_is_bigdecimal else val_expr
            else:
                final_expr = val_expr
            return self.generate_assignment(tgt, final_expr)
            
        tgt_base = re.split(r'\(', tgt)[0].strip()
        tgt_pic = self.current_generator.var_pics.get(tgt_base.upper(), "") if self.current_generator else ""
        if tgt_pic:
            _, digits, scale, signed = NativeTypeMapper.parse_pic(tgt_pic)
        else:
            digits, scale, signed = 18, 0, True
            
        temp_eval = val_expr if val_is_bigdecimal else f"BigDecimal.valueOf({val_expr})"
        
        on_size_code = "\n            ".join(self.translate_statement(n) for n in on_size_nodes if self.translate_statement(n))
        not_size_code = "\n            ".join(self.translate_statement(n) for n in not_size_nodes if self.translate_statement(n))
        
        assignment = self.generate_assignment(tgt, "val_temp")
        if tgt_type == "Integer":
            assignment = self.generate_assignment(tgt, "val_temp.intValue()")
        elif tgt_type == "Long":
            assignment = self.generate_assignment(tgt, "val_temp.longValue()")
            
        lines = [
            "{",
            "    try {",
            f"        BigDecimal val_temp = {temp_eval};",
            f"        if (checkSizeError(val_temp, {digits}, {scale}, {'true' if signed else 'false'})) {{",
            f"            {on_size_code}",
            "        } else {",
            f"            {assignment}",
            f"            {not_size_code}",
            "        }",
            "    } catch (ArithmeticException e) {",
            f"        {on_size_code}",
            "    }",
            "}"
        ]
        return "\n        ".join(lines)

    def _translate_statement_inner(self, node) -> str:
        props = node.properties if hasattr(node, "properties") else node.get("properties", {})
        stype = props.get("statement_type", "").upper()
        
        if stype == "MOVE":
            src = props.get("source", "")
            raw_tgt = props.get("targets") or props.get("target")
            targets = raw_tgt if isinstance(raw_tgt, list) else ([raw_tgt] if raw_tgt else [])
            
            assignments = []
            for tgt in targets:
                tgt_type = self._get_var_type(tgt, "String")
                
                src_upper = src.upper()
                if src_upper in ("SPACE", "SPACES"):
                    java_src = '""'
                elif src_upper in ("ZERO", "ZEROS", "ZEROES"):
                    java_src = 'BigDecimal.ZERO' if tgt_type == "BigDecimal" else "0"
                    tgt_pic = self.current_generator.var_pics.get(re.split(r'\(', tgt)[0].strip(), "") if self.current_generator else ""
                    if tgt_type == "String" and "Z" in tgt_pic.upper():
                        _, length, _, _ = NativeTypeMapper.parse_pic(tgt_pic)
                        java_src = f"String.format(\"%{length}d\", 0)"
                elif src_upper in ("HIGH-VALUE", "HIGH-VALUES"):
                    java_src = '"\\uFFFF"'
                elif src.startswith("'") or src.startswith('"'):
                    java_src = src
                elif re.match(r'^\d+(\.\d+)?$', src):
                    if tgt_type == "BigDecimal":
                        java_src = f"new BigDecimal(\"{src}\")"
                    elif tgt_type in ("Integer", "Long"):
                        java_src = src
                    else:
                        tgt_pic = self.current_generator.var_pics.get(re.split(r'\(', tgt)[0].strip(), "") if self.current_generator else ""
                        if tgt_type == "String" and "Z" in tgt_pic.upper():
                            _, length, _, _ = NativeTypeMapper.parse_pic(tgt_pic)
                            java_src = f"String.format(\"%{length}d\", {src})"
                        else:
                            java_src = f"\"{src}\""
                elif self._is_variable(src):
                    java_src = self.translate_math_operand(src, tgt_type)
                    src_type = self._get_var_type(src, "String")
                    if tgt_type == "BigDecimal" and src_type in ("Integer", "Long"):
                        java_src = f"BigDecimal.valueOf({java_src})"
                    elif tgt_type == "String" and src_type != "String":
                        tgt_pic = self.current_generator.var_pics.get(re.split(r'\(', tgt)[0].strip(), "") if self.current_generator else ""
                        if "Z" in tgt_pic.upper():
                            _, length, _, _ = NativeTypeMapper.parse_pic(tgt_pic)
                            java_src = f"String.format(\"%{length}d\", {java_src})"
                        else:
                            java_src = f"String.valueOf({java_src})"
                else:
                    java_src = f"\"{src}\""
                
                assignments.append(self.generate_assignment(tgt, java_src))
            
            return "\n        ".join(assignments) if assignments else ""
 
        elif stype == "COMPUTE":
            tgt = props.get("target", "")
            expr = props.get("expression", "")
            tgt_type = self._get_var_type(tgt, "BigDecimal")
            translated_expr = self.expr_trans.translate(expr)
            return self.wrap_math_with_size_error(tgt, translated_expr, props, tgt_type, val_is_bigdecimal=True)
 
        elif stype in ("ADD", "SUBTRACT", "MULTIPLY", "DIVIDE"):
            val = props.get("value", "")
            tgt = props.get("target", "")
            operand2 = props.get("operand2")
            
            tgt_type = self._get_var_type(tgt, "BigDecimal")
            java_tgt_read = self.translate_math_operand(tgt, tgt_type)
            
            if re.match(r'^\d+(\.\d+)?$', val):
                java_val = f"new BigDecimal(\"{val}\")" if tgt_type == "BigDecimal" else val
            else:
                java_val = self.translate_math_operand(val, tgt_type)
            
            if operand2:
                java_op2 = self.translate_math_operand(operand2, tgt_type)
                
                if stype == "ADD":
                    val_expr = f"{java_val}.add({java_op2})" if tgt_type == "BigDecimal" else f"{java_val} + {java_op2}"
                elif stype == "SUBTRACT":
                    val_expr = f"{java_op2}.subtract({java_val})" if tgt_type == "BigDecimal" else f"{java_op2} - {java_val}"
                elif stype == "MULTIPLY":
                    val_expr = f"{java_val}.multiply({java_op2})" if tgt_type == "BigDecimal" else f"{java_val} * {java_op2}"
                else:
                    val_expr = f"{java_val}.divide({java_op2}, 2, RoundingMode.DOWN)" if tgt_type == "BigDecimal" else f"{java_val} / {java_op2}"
            else:
                if stype == "ADD":
                    val_expr = f"{java_tgt_read}.add({java_val})" if tgt_type == "BigDecimal" else f"{java_tgt_read} + {java_val}"
                elif stype == "SUBTRACT":
                    val_expr = f"{java_tgt_read}.subtract({java_val})" if tgt_type == "BigDecimal" else f"{java_tgt_read} - {java_val}"
                elif stype == "MULTIPLY":
                    val_expr = f"{java_tgt_read}.multiply({java_val})" if tgt_type == "BigDecimal" else f"{java_tgt_read} * {java_val}"
                else:
                    val_expr = f"{java_tgt_read}.divide({java_val}, 2, RoundingMode.DOWN)" if tgt_type == "BigDecimal" else f"{java_tgt_read} / {java_val}"
                    
            return self.wrap_math_with_size_error(tgt, val_expr, props, tgt_type, val_is_bigdecimal=(tgt_type == "BigDecimal"))

        elif stype == "IF":
            cond = self._translate_condition(props.get("condition", ""))
            return f"if ({cond}) {{"
            
        elif stype == "ELSE":
            return "} else {"
            
        elif stype == "END-IF":
            return "}"

        elif stype == "PERFORM_UNTIL":
            cond = self._translate_condition(props.get("condition", ""))
            return f"while (!({cond})) {{"

        elif stype == "PERFORM_VARYING":
            idx = props.get("index", "")
            from_val = props.get("from_value", "1")
            by_val = props.get("by_value", "1")
            cond = self._translate_condition(props.get("condition", ""))
            java_idx = to_java_var(idx)
            idx_type = self.var_types.get(idx, "Integer")
            if idx_type == "BigDecimal":
                # Use BigDecimal loop variable
                by_expr = f"new BigDecimal(\"{by_val}\")" if re.match(r'^\d+(\.\d+)?$', by_val) else to_java_var(by_val)
                from_expr = f"new BigDecimal(\"{from_val}\")" if re.match(r'^\d+(\.\d+)?$', from_val) else to_java_var(from_val)
                return (f"for ({java_idx} = {from_expr}; !({cond}); "
                        f"{java_idx} = {java_idx}.add({by_expr})) {{")
            else:
                t_prim = "int" if idx_type == "Integer" else "long"
                return (f"for ({java_idx} = {from_val}; !({cond}); "
                        f"{java_idx} += {by_val}) {{")

        elif stype == "END-PERFORM":
            return "}"

        elif stype == "PERFORM":
            tgt = props.get("target", "")
            thru = props.get("thru", None)
            java_tgt = to_java_var(tgt)
            java_thru = to_java_var(thru) if thru else None
            if java_thru:
                return f"perform(\"{java_tgt}\", \"{java_thru}\");\n        if (nextParagraphIndex != -1) return;"
            else:
                return f"perform(\"{java_tgt}\", null);\n        if (nextParagraphIndex != -1) return;"

        elif stype == "OPEN":
            open_calls = []
            targets = props.get("targets", [])
            if not targets and props.get("target"):
                targets = [props.get("target")]
                
            curr_mode = "INPUT"
            for t in targets:
                t_upper = t.upper()
                if t_upper in ("INPUT", "OUTPUT", "I-O", "EXTEND"):
                    curr_mode = t_upper
                    continue
                open_calls.append(f"open_{to_java_var(t)}();")
            return "\n        ".join(open_calls)

        elif stype == "CLOSE":
            close_calls = []
            targets = props.get("targets", [])
            if not targets and props.get("target"):
                targets = [props.get("target")]
                
            for t in targets:
                t_upper = t.upper()
                if t_upper in ("INPUT", "OUTPUT", "I-O", "EXTEND"):
                    # skip mode keywords if any slip in
                    continue
                close_calls.append(f"close_{to_java_var(t)}();")
            return "\n        ".join(close_calls)

        elif stype == "READ":
            tgt = props.get("target", "")
            into_target = props.get("into_target")
            at_end_nodes = props.get("at_end_nodes", [])
            not_at_end_nodes = props.get("not_at_end_nodes", [])
            invalid_key_nodes = props.get("invalid_key_nodes", [])
            not_invalid_key_nodes = props.get("not_invalid_key_nodes", [])
            
            java_tgt = to_java_var(tgt)
            
            rec_name = None
            for r, fd in self.record_to_fd.items():
                if fd.upper() == tgt.upper():
                    rec_name = r
                    break
            if not rec_name:
                rec_name = tgt
                
            org = "SEQUENTIAL"
            access_mode = "SEQUENTIAL"
            record_key = None
            if self.current_generator:
                org = self.current_generator.file_orgs.get(tgt.upper(), "SEQUENTIAL")
                access_mode = self.current_generator.file_access_modes.get(tgt.upper(), "SEQUENTIAL")
                record_key = self.current_generator.file_keys.get(tgt.upper())
                
            is_keyed = (org == "INDEXED" and access_mode in ("RANDOM", "DYNAMIC"))
            
            key_expr = "null"
            if record_key:
                key_jvar = to_java_var(record_key)
                if self.current_generator and record_key.upper() in self.current_generator.redefines_layout:
                    key_expr = f"get_{key_jvar}()"
                else:
                    key_expr = key_jvar
            
            if not at_end_nodes and not not_at_end_nodes and not invalid_key_nodes and not not_invalid_key_nodes and not into_target:
                if is_keyed:
                    return f"read_{java_tgt}_key({key_expr});"
                else:
                    return f"read_{java_tgt}();"
                    
            lines = []
            if is_keyed:
                lines.append(f"if (!read_{java_tgt}_key({key_expr})) {{")
                for node in invalid_key_nodes:
                    stmt_str = self.translate_statement(node)
                    if stmt_str:
                        lines.append(f"    {stmt_str}")
                lines.append("} else {")
                if into_target:
                    java_rec = to_java_var(rec_name)
                    java_into = to_java_var(into_target)
                    lines.append(f"    {java_into} = {java_rec};")
                for node in not_invalid_key_nodes:
                    stmt_str = self.translate_statement(node)
                    if stmt_str:
                        lines.append(f"    {stmt_str}")
                lines.append("}")
                return "\n        ".join(lines)
            else:
                lines.append(f"if (!read_{java_tgt}()) {{")
                for node in at_end_nodes:
                    stmt_str = self.translate_statement(node)
                    if stmt_str:
                        lines.append(f"    {stmt_str}")
                lines.append("} else {")
                if into_target:
                    java_rec = to_java_var(rec_name)
                    java_into = to_java_var(into_target)
                    lines.append(f"    {java_into} = {java_rec};")
                for node in not_at_end_nodes:
                    stmt_str = self.translate_statement(node)
                    if stmt_str:
                        lines.append(f"    {stmt_str}")
                lines.append("}")
                return "\n        ".join(lines)

        elif stype == "WRITE":
            tgt = props.get("target", "")
            from_source = props.get("from_source")
            invalid_key_nodes = props.get("invalid_key_nodes", [])
            not_invalid_key_nodes = props.get("not_invalid_key_nodes", [])
            
            matched_fd = self._get_matched_fd(tgt)
            java_tgt = to_java_var(matched_fd)
            
            org = "SEQUENTIAL"
            if self.current_generator:
                org = self.current_generator.file_orgs.get(matched_fd.upper(), "SEQUENTIAL")
                
            lines = []
            if from_source:
                java_src = to_java_var(from_source)
                java_rec = to_java_var(tgt)
                lines.append(f"{java_rec} = {java_src};")
                
            if org == "INDEXED" and (invalid_key_nodes or not_invalid_key_nodes):
                lines.append(f"if (!write_{java_tgt}()) {{")
                for node in invalid_key_nodes:
                    stmt_str = self.translate_statement(node)
                    if stmt_str:
                        lines.append(f"    {stmt_str}")
                lines.append("} else {")
                for node in not_invalid_key_nodes:
                    stmt_str = self.translate_statement(node)
                    if stmt_str:
                        lines.append(f"    {stmt_str}")
                lines.append("}")
            else:
                lines.append(f"write_{java_tgt}();")
            return "\n        ".join(lines)

        elif stype == "REWRITE":
            tgt = props.get("target", "")
            from_source = props.get("from_source")
            invalid_key_nodes = props.get("invalid_key_nodes", [])
            not_invalid_key_nodes = props.get("not_invalid_key_nodes", [])
            
            matched_fd = self._get_matched_fd(tgt)
            java_tgt = to_java_var(matched_fd)
            
            org = "SEQUENTIAL"
            if self.current_generator:
                org = self.current_generator.file_orgs.get(matched_fd.upper(), "SEQUENTIAL")
                
            lines = []
            if from_source:
                java_src = to_java_var(from_source)
                java_rec = to_java_var(tgt)
                lines.append(f"{java_rec} = {java_src};")
                
            if org == "INDEXED" and (invalid_key_nodes or not_invalid_key_nodes):
                lines.append(f"if (!rewrite_{java_tgt}()) {{")
                for node in invalid_key_nodes:
                    stmt_str = self.translate_statement(node)
                    if stmt_str:
                        lines.append(f"    {stmt_str}")
                lines.append("} else {")
                for node in not_invalid_key_nodes:
                    stmt_str = self.translate_statement(node)
                    if stmt_str:
                        lines.append(f"    {stmt_str}")
                lines.append("}")
            else:
                if org == "INDEXED":
                    lines.append(f"rewrite_{java_tgt}();")
                else:
                    lines.append(f"write_{java_tgt}();")
            return "\n        ".join(lines)

        elif stype == "GOBACK":
            return "if (true) { programExited = true; return; }"
        elif stype == "STOP RUN":
            return "if (true) { throw new StopRunException(); }"

        elif stype == "GO TO":
            target = to_java_var(props.get("target", ""))
            # Unresolved target paragraph diagnostic
            if self.current_generator and target not in self.current_generator.paragraphs:
                diag = {
                    "construct": "GO TO",
                    "source": f"{node.source_file}:{node.source_line}",
                    "severity": "ERROR",
                    "status": "UNSUPPORTED",
                    "detail": f"Unresolved GO TO target paragraph '{target}'"
                }
                self.current_generator.diagnostics.append(diag)
            return f"if (true) {{ nextParagraphIndex = getParagraphIndex(\"{target}\"); return; }}"

        elif stype == "CONTINUE":
            return ";"

        elif stype == "EXIT PERFORM":
            return "if (true) break;"

        elif stype == "EXIT PARAGRAPH":
            return "if (true) return;"

        elif stype == "EXIT SECTION":
            next_sec = None
            if self.current_generator and hasattr(self.current_generator, "current_paragraph"):
                curr_p = self.current_generator.current_paragraph
                next_sec = self.current_generator.next_section_map.get(curr_p)
            
            if next_sec:
                return f"if (true) {{ nextParagraphIndex = getParagraphIndex(\"{next_sec}\"); return; }}"
            else:
                total_paras = len(self.current_generator.paragraphs) if self.current_generator else 9999
                return f"if (true) {{ nextParagraphIndex = {total_paras}; return; }}"

        elif stype == "NEXT SENTENCE":
            return "skipToNextSentence = true;"

        elif stype == "PERFORM_TIMES":
            count_var = props.get("count", "0")
            java_count = to_java_var(count_var)
            if self._is_variable(count_var):
                count_type = self._get_var_type(count_var, "Integer")
                if count_type == "BigDecimal":
                    limit_expr = f"{java_count}.intValue()"
                else:
                    limit_expr = java_count
            else:
                limit_expr = java_count
            
            loop_idx = f"loopIdx_{self.call_counter}"
            self.call_counter += 1
            return f"for (int {loop_idx} = 0; {loop_idx} < {limit_expr}; {loop_idx}++) {{"

        elif stype == "PERFORM_TIMES_OUT":
            target = props.get("target", "")
            thru = props.get("thru")
            count_var = props.get("count", "0")
            java_tgt = to_java_var(target)
            java_thru = to_java_var(thru) if thru else None
            
            java_count = to_java_var(count_var)
            if self._is_variable(count_var):
                count_type = self._get_var_type(count_var, "Integer")
                if count_type == "BigDecimal":
                    limit_expr = f"{java_count}.intValue()"
                else:
                    limit_expr = java_count
            else:
                limit_expr = java_count
                
            loop_idx = f"loopIdx_{self.call_counter}"
            self.call_counter += 1
            
            thru_expr = f"\"{java_thru}\"" if java_thru else "null"
            lines = [
                f"for (int {loop_idx} = 0; {loop_idx} < {limit_expr}; {loop_idx}++) {{",
                f"    if (skipToNextSentence) break;",
                f"    perform(\"{java_tgt}\", {thru_expr});",
                f"    if (nextParagraphIndex != -1) return;",
                f"}}"
            ]
            return "\n        ".join(lines)

        elif stype == "STRING":
            parts = props.get("parts", [])
            tgt = props.get("target", "")
            java_tgt = to_java_var(tgt)
            
            java_parts = []
            for part in parts:
                val = part.get("value", "")
                if val.startswith("'") or val.startswith('"'):
                    val_clean = val[1:-1].replace('"', '\\"')
                    java_parts.append(f"\"{val_clean}\"")
                elif val in self.var_types:
                    java_var = to_java_var(val)
                    var_type = self.var_types.get(val, "String")
                    if var_type == "String":
                        java_parts.append(java_var)
                    else:
                        java_parts.append(f"String.valueOf({java_var})")
                else:
                    java_parts.append(f"\"{val}\"")
            
            concat_expr = " + ".join(java_parts)
            return self.generate_assignment(tgt, concat_expr)

        elif stype == "UNSTRING":
            source = props.get("source", "")
            delimited_by = props.get("delimited_by")
            targets = props.get("targets", [])
            pointer = props.get("pointer")
            tallying = props.get("tallying")
            on_overflow = props.get("on_overflow_nodes", [])
            not_on_overflow = props.get("not_on_overflow_nodes", [])
            
            if source.startswith("'") or source.startswith('"'):
                src_expr = f"\"{source[1:-1].replace('\"', '\\\"')}\""
            elif source in self.var_types:
                j_src = to_java_var(source)
                src_expr = f"get_{j_src}()" if source in self.redefines_layout else j_src
                if self.var_types.get(source) != "String":
                    src_expr = f"String.valueOf({src_expr})"
            else:
                src_expr = f"\"{source}\""
                
            if delimited_by:
                if delimited_by.startswith("'") or delimited_by.startswith('"'):
                    delim_expr = f"\"{delimited_by[1:-1].replace('\"', '\\\"')}\""
                elif delimited_by in self.var_types:
                    j_delim = to_java_var(delimited_by)
                    delim_expr = f"get_{j_delim}()" if delimited_by in self.redefines_layout else j_delim
                    if self.var_types.get(delimited_by) != "String":
                        delim_expr = f"String.valueOf({delim_expr})"
                else:
                    delim_expr = f"\"{delimited_by}\""
            else:
                delim_expr = "null"
                
            if pointer:
                j_ptr = to_java_var(pointer)
                ptr_init = f"get_{j_ptr}()" if pointer in self.redefines_layout else j_ptr
                if self.var_types.get(pointer) != "Integer" and self.var_types.get(pointer) != "Long":
                    ptr_init = f"((int) parseSignedLong(String.valueOf({ptr_init})))"
            else:
                ptr_init = "1"
                
            assignments = []
            for i, tgt in enumerate(targets):
                tgt_base = re.split(r'\(', tgt)[0].strip()
                tgt_type = self._get_var_type(tgt_base, "String")
                val_expr = f"unstring_targets[{i}]"
                
                if tgt_type == "BigDecimal":
                    conv_expr = f"new BigDecimal({val_expr}.trim().isEmpty() ? \"0\" : {val_expr}.trim())"
                elif tgt_type == "Integer":
                    conv_expr = f"Integer.parseInt({val_expr}.trim().isEmpty() ? \"0\" : {val_expr}.trim())"
                elif tgt_type == "Long":
                    conv_expr = f"Long.parseLong({val_expr}.trim().isEmpty() ? \"0\" : {val_expr}.trim())"
                else:
                    conv_expr = val_expr
                    
                assignments.append(self.generate_assignment(tgt, conv_expr))
            assignments_str = "\n            ".join(assignments)
            
            if pointer:
                ptr_upd = self.generate_assignment(pointer, "unstring_idx + 1")
            else:
                ptr_upd = ""
                
            if tallying:
                tally_upd = self.generate_assignment(tallying, f"({to_java_var(tallying)} + unstring_fields_processed)")
            else:
                tally_upd = ""
                
            on_overflow_code = "\n            ".join(self.translate_statement(n) for n in on_overflow if self.translate_statement(n))
            not_on_overflow_code = "\n            ".join(self.translate_statement(n) for n in not_on_overflow if self.translate_statement(n))
            
            lines = [
                "{",
                f"    String unstring_src = {src_expr};",
                f"    int unstring_ptr = {ptr_init};",
                "    boolean unstring_overflow = false;",
                "    if (unstring_ptr < 1 || unstring_ptr > unstring_src.length() + 1) {",
                "        unstring_overflow = true;",
                "    } else {",
                f"        String[] unstring_targets = new String[{len(targets)}];",
                "        int unstring_idx = unstring_ptr - 1;",
                f"        String unstring_delim = {delim_expr};",
                "        int unstring_fields_processed = 0;",
                f"        for (int i = 0; i < {len(targets)}; i++) {{",
                "            if (unstring_idx > unstring_src.length()) {",
                "                unstring_targets[i] = \"\";",
                "                continue;",
                "            }",
                "            int next_delim = -1;",
                "            if (unstring_delim != null && !unstring_delim.isEmpty()) {",
                "                next_delim = unstring_src.indexOf(unstring_delim, unstring_idx);",
                "            }",
                "            String field_val;",
                "            if (next_delim != -1) {",
                "                field_val = unstring_src.substring(unstring_idx, next_delim);",
                "                unstring_idx = next_delim + unstring_delim.length();",
                "            } else {",
                "                field_val = unstring_src.substring(unstring_idx);",
                "                unstring_idx = unstring_src.length() + 1;",
                "            }",
                "            unstring_targets[i] = field_val;",
                "            unstring_fields_processed++;",
                "        }",
                f"        {ptr_upd}",
                f"        {tally_upd}",
                f"        {assignments_str}",
                "    }",
                "    if (unstring_overflow) {",
                f"        {on_overflow_code}",
                "    } else {",
                f"        {not_on_overflow_code}",
                "    }",
                "}"
            ]
            return "\n        ".join(lines)

        elif stype == "INSPECT":
            target = props.get("target", "")
            inspect_type = props.get("inspect_type")
            tally_var = props.get("tally_var")
            tally_type = props.get("tally_type")
            tally_search = props.get("tally_search")
            replacements = props.get("replacements", [])
            converting_from = props.get("converting_from")
            converting_to = props.get("converting_to")
            
            java_tgt = to_java_var(target)
            tgt_read = f"get_{java_tgt}()" if target in self.redefines_layout else java_tgt
            
            def get_val_expr(val):
                if val is None:
                    return '""'
                if val.startswith("'") or val.startswith('"'):
                    return f"\"{val[1:-1].replace('\"', '\\\"')}\""
                elif val.upper() == "SPACE" or val.upper() == "SPACES":
                    return '" "'
                elif val.upper() == "ZERO" or val.upper() == "ZEROS":
                    return '"0"'
                elif val in self.var_types:
                    var_t = self.var_types.get(val, "String")
                    j_var = to_java_var(val)
                    j_val = f"get_{j_var}()" if val in self.redefines_layout else j_var
                    return j_val if var_t == "String" else f"String.valueOf({j_val})"
                else:
                    return f"\"{val}\""
                    
            if inspect_type == "TALLYING":
                j_tally = to_java_var(tally_var)
                tally_update_prefix = f"{j_tally} = get_{j_tally}()" if tally_var in self.redefines_layout else f"{j_tally} = {j_tally}"
                
                if tally_type == "CHARACTERS":
                    return self.generate_assignment(tally_var, f"({tally_update_prefix} + {tgt_read}.length())")
                elif tally_type == "ALL":
                    lines = [
                        "{",
                        "    int count = 0;",
                        "    int idx = 0;",
                        f"    String s_target = {tgt_read};",
                        f"    String s_search = {get_val_expr(tally_search)};",
                        "    if (!s_search.isEmpty()) {",
                        "        while ((idx = s_target.indexOf(s_search, idx)) != -1) {",
                        "            count++;",
                        "            idx += s_search.length();",
                        "        }",
                        "    }",
                        f"    {self.generate_assignment(tally_var, f'({tally_update_prefix} + count)')}",
                        "}"
                    ]
                    return "\n        ".join(lines)
                elif tally_type == "LEADING":
                    lines = [
                        "{",
                        "    int count = 0;",
                        f"    String s_target = {tgt_read};",
                        f"    String s_search = {get_val_expr(tally_search)};",
                        "    if (!s_search.isEmpty()) {",
                        "        int len = s_search.length();",
                        "        while (s_target.startsWith(s_search)) {",
                        "            count++;",
                        "            s_target = s_target.substring(len);",
                        "        }",
                        "    }",
                        f"    {self.generate_assignment(tally_var, f'({tally_update_prefix} + count)')}",
                        "}"
                    ]
                    return "\n        ".join(lines)
                    
            elif inspect_type == "REPLACING":
                lines = [
                    "{",
                    f"    String temp_inspect = {tgt_read};"
                ]
                for rep in replacements:
                    rep_t = rep.get("type")
                    search = get_val_expr(rep.get("search"))
                    replace = get_val_expr(rep.get("replace"))
                    
                    if rep_t == "ALL":
                        lines.append(f"    temp_inspect = temp_inspect.replace({search}, {replace});")
                    elif rep_t == "FIRST":
                        lines.append(f"    temp_inspect = temp_inspect.replaceFirst(java.util.regex.Pattern.quote({search}), {replace});")
                    elif rep_t == "CHARACTERS":
                        lines.append(f"    StringBuilder sb = new StringBuilder();")
                        lines.append(f"    char rep_char = {replace}.isEmpty() ? ' ' : {replace}.charAt(0);")
                        lines.append(f"    for (int i = 0; i < temp_inspect.length(); i++) sb.append(rep_char);")
                        lines.append(f"    temp_inspect = sb.toString();")
                    elif rep_t == "LEADING":
                        lines.append(f"    if (!{search}.isEmpty()) {{")
                        lines.append(f"        int len = {search}.length();")
                        lines.append(f"        StringBuilder sb = new StringBuilder();")
                        lines.append(f"        while (temp_inspect.startsWith({search})) {{")
                        lines.append(f"            sb.append({replace});")
                        lines.append(f"            temp_inspect = temp_inspect.substring(len);")
                        lines.append(f"        }}")
                        lines.append(f"        sb.append(temp_inspect);")
                        lines.append(f"        temp_inspect = sb.toString();")
                        lines.append(f"    }}")
                lines.append(f"    {self.generate_assignment(target, 'temp_inspect')}")
                lines.append("}")
                return "\n        ".join(lines)
                
            elif inspect_type == "CONVERTING":
                lines = [
                    "{",
                    f"    String from_chars = {get_val_expr(converting_from)};",
                    f"    String to_chars = {get_val_expr(converting_to)};",
                    f"    String s_target = {tgt_read};",
                    "    StringBuilder sb = new StringBuilder();",
                    "    for (int i = 0; i < s_target.length(); i++) {",
                    "        char c = s_target.charAt(i);",
                    "        int idx = from_chars.indexOf(c);",
                    "        if (idx != -1 && idx < to_chars.length()) {",
                    "            sb.append(to_chars.charAt(idx));",
                    "        } else {",
                    "            sb.append(c);",
                    "        }",
                    "    }",
                    f"    {self.generate_assignment(target, 'sb.toString()')}",
                    "}"
                ]
                return "\n        ".join(lines)

        elif stype == "CALL":
            target = props.get("target", "")
            arguments = props.get("arguments", [])
            
            def get_flat_vars(prog_gen, arg_names):
                flat = []
                for arg in arg_names:
                    arg_upper = arg.upper()
                    if arg_upper in prog_gen.group_fields:
                        for child in prog_gen.group_fields[arg_upper]:
                            flat.append(child)
                    else:
                        flat.append(arg)
                return flat

            if not self.current_generator:
                return f"// CALL translation error: current_generator not set"

            caller_vars = get_flat_vars(self.current_generator, arguments)
            is_dynamic = target in self.var_types
            
            if is_dynamic:
                java_var = to_java_var(target)
                lines = []
                lines.append(f"String targetProg_{java_var} = {java_var}.trim().toUpperCase();")
                first = True
                for other_prog_name, other_gen in self.all_generators.items():
                    if other_prog_name == self.current_generator.program_name:
                        continue
                    cond = "if" if first else "else if"
                    first = False
                    lines.append(f"{cond} (targetProg_{java_var}.equals(\"{other_prog_name.upper()}\")) {{")
                    call_lines = self._generate_call_block(other_prog_name, other_gen, caller_vars)
                    for cl in call_lines:
                        lines.append(f"    {cl}")
                    lines.append("}")
                return "\n        ".join(lines)
            else:
                target_upper = target.upper()
                if target_upper in self.all_generators:
                    other_gen = self.all_generators[target_upper]
                    call_lines = self._generate_call_block(target_upper, other_gen, caller_vars)
                    return "\n        ".join(call_lines)
                else:
                    return f"// Call to unknown program: {target}"

        elif stype == "EVALUATE":
            self.evaluate_count = 0
            self.evaluate_subject = props.get("subject", None)
            return None  # emit nothing; WHEN handlers generate the if/else chain

        elif stype == "WHEN":
            self.evaluate_count += 1
            cond = props.get("condition", "")
            cond_upper = cond.upper().strip()
            if cond_upper == "OTHER":
                return "} else {"

            subject = self.evaluate_subject
            if subject:
                # Type-aware subject == cond comparison
                subj_java = to_java_var(subject) if subject in self.var_types else subject
                subj_type = self.var_types.get(subject, "String")
                cond_stripped = cond.strip().strip("'\"")
                if subj_type == "BigDecimal":
                    r_val = (f"new BigDecimal(\"{cond_stripped}\")"
                             if re.match(r'^\d+(\.\d+)?$', cond_stripped)
                             else to_java_var(cond_stripped))
                    java_cond = f"{subj_java}.compareTo({r_val}) == 0"
                elif subj_type in ("Integer", "Long"):
                    java_cond = f"{subj_java} == {cond_stripped}"
                else:
                    java_cond = f"Objects.equals({subj_java}, \"{cond_stripped}\")"
            else:
                java_cond = self._translate_condition(cond)

            if self.evaluate_count == 1:
                return f"if ({java_cond}) {{"
            else:
                return f"}} else if ({java_cond}) {{"

        elif stype == "END-EVALUATE":
            return "}"

        elif stype == "DISPLAY":
            operands = props.get("operands", [])
            if not operands:
                return 'System.out.println("");'
            parts = []
            for op in operands:
                val = op.get("value", "")
                op_type = op.get("type", "variable")
                if op_type == "literal":
                    clean = val.replace('"', '\\"')
                    parts.append(f"\"{clean}\"")
                else:
                    v_type = self._get_var_type(val)
                    jv = self.expr_trans.translate(val)
                    if jv.startswith("BigDecimal.valueOf(") and jv.endswith(")"):
                        jv = jv[len("BigDecimal.valueOf("):-1]
                        
                    val_base = re.split(r'\(', val)[0].strip()
                    pic = self.current_generator.var_pics.get(val_base.upper(), "") if self.current_generator else ""
                    if pic and "9" in pic and "X" not in pic:
                        _, digits, scale, signed = NativeTypeMapper.parse_pic(pic)
                        if v_type == "BigDecimal":
                            parts.append(f"String.format(\"%0{(digits + (1 if scale > 0 else 0))}d\", {jv}.movePointRight({scale}).longValue())")
                        else:
                            parts.append(f"String.format(\"%0{digits}d\", {jv})")
                    else:
                        if v_type == "String":
                            parts.append(jv)
                        else:
                            parts.append(f"String.valueOf({jv})")
            concat = ' + " " + '.join(parts) if len(parts) > 1 else parts[0]
            return f"System.out.println({concat});"

        if stype and self.current_generator is not None:
            node_id = None
            source_coord = "UNKNOWN"
            if hasattr(node, "node_id"):
                node_id = node.node_id
            if hasattr(node, "source_line") and node.source_line:
                src_file = getattr(node, "source_file", "") or ""
                source_coord = f"{os.path.basename(src_file)}:{node.source_line}" if src_file else f"line:{node.source_line}"
            self.current_generator.diagnostics.append({
                "construct": stype,
                "source_coordinate": source_coord,
                "semantic_ir_node": node_id,
                "severity": "ERROR",
                "status": "NATIVE_TRANSLATION_BLOCKED",
                "reason": f"Statement type '{stype}' has no native Java translation"
            })
        return f"// UNSUPPORTED: {stype}"

    def _translate_subscripts(self, expr: str) -> str:
        pattern = r'(?<![A-Za-z0-9_-])([A-Za-z0-9_-]+)\s*\(\s*([^()]+)\s*\)'
        def repl(match):
            var_name = to_java_var(match.group(1))
            idx = match.group(2).strip()
            for v in self.var_types.keys():
                idx = re.sub(r'\b' + re.escape(v) + r'\b', to_java_var(v), idx)
            if idx.isdigit():
                return f"{var_name}[{int(idx) - 1}]"
            return f"{var_name}[{idx} - 1]"
        
        old = ""
        while old != expr:
            old = expr
            expr = re.sub(pattern, repl, expr)
        return expr

    def _translate_condition(self, cond: str) -> str:
        """Translate a COBOL condition string to Java boolean expression."""
        cond = self._translate_subscripts(cond)
        # Resolve Level-88 conditions
        for cond_name in self.level88_map.keys():
            pattern = r'(?<![A-Za-z0-9_-])' + re.escape(cond_name) + r'(?![A-Za-z0-9_-])'
            method_call = to_java_method(cond_name) + "()"
            cond = re.sub(pattern, method_call, cond, flags=re.IGNORECASE)

        cond = cond.replace("=", "==").replace("<>", "!=")
        for v in self.var_types.keys():
            cond = re.sub(r'\b' + re.escape(v) + r'\b', to_java_var(v), cond)
        for v, t in self.var_types.items():
            jv = to_java_var(v)
            if t == "BigDecimal":
                pattern = r'\b' + re.escape(jv) + r'(\[[^\]]+\])?\s*(==|!=|>|<|>=|<=)\s*([A-Za-z0-9_\-\.]+)\b'
                def repl_bd(match, _jv=jv):
                    sub = match.group(1) or ""
                    op = match.group(2)
                    right = match.group(3)
                    r_val = f"new BigDecimal(\"{right}\")" if re.match(r'^\d+(\.\d+)?$', right) else right
                    map_ops = {"==": "== 0", "!=": "!= 0", ">": "> 0", "<": "< 0", ">=": ">= 0", "<=": "<= 0"}
                    return f"{_jv}{sub}.compareTo({r_val}) {map_ops.get(op, op)}"
                cond = re.sub(pattern, repl_bd, cond)
            elif t == "String":
                pattern = r'\b' + re.escape(jv) + r'(\[[^\]]+\])?\s*(==|!=)\s*(\"[^\"]*\"|\'[^\']*\'|[A-Za-z0-9_\-\.]+)'
                def repl_str(match, _jv=jv):
                    sub = match.group(1) or ""
                    op = match.group(2)
                    right = match.group(3)
                    if right.startswith("'") or right.startswith('"'):
                        right = f"\"{right[1:-1]}\""
                    else:
                        right = to_java_var(right)
                    return f"{_jv}{sub}.equals({right})" if op == "==" else f"!{_jv}{sub}.equals({right})"
                cond = re.sub(pattern, repl_str, cond)
        return cond

    def _generate_call_block(self, target_name: str, target_gen, caller_vars: list) -> list:
        self.call_counter += 1
        suffix = f"_{self.call_counter}"
        target_vars = []
        for arg in target_gen.using_args:
            arg_upper = arg.upper()
            if arg_upper in target_gen.group_fields:
                for child in target_gen.group_fields[arg_upper]:
                    target_vars.append(child)
            else:
                target_vars.append(arg)
                
        java_class = to_java_class(target_name)
        var_name = to_java_var(target_name) + suffix
        
        lines = []
        lines.append(f"{java_class} {var_name} = new {java_class}();")
        
        for i, c_var in enumerate(caller_vars):
            if i < len(target_vars):
                t_var = target_vars[i]
                c_jvar = to_java_var(c_var)
                t_jvar = to_java_var(t_var)
                lines.append(f"{var_name}.{t_jvar} = {c_jvar};")
                
        lines.append(f"{var_name}.execute();")
        
        for i, c_var in enumerate(caller_vars):
            if i < len(target_vars):
                t_var = target_vars[i]
                c_jvar = to_java_var(c_var)
                t_jvar = to_java_var(t_var)
                lines.append(f"{c_jvar} = {var_name}.{t_jvar};")
                
        return lines

class NativeFileIOGenerator:
    @staticmethod
    def generate_io_methods(fd_name: str, assign_path: str, is_input: bool, record_fields: list,
                            redefined_record_name: str = None, redefined_record_len: int = None,
                            organization: str = "SEQUENTIAL", record_key: str = None,
                            status_var: str = None, redefines_layout: dict = None) -> str:
        java_fd = to_java_var(fd_name)
        
        offsets = []
        curr = 0
        for f_name, pic in record_fields:
            _, length, _, _ = NativeTypeMapper.parse_pic(pic)
            offsets.append((f_name, curr, curr + length))
            curr += length
            
        def get_status_assign(val):
            if not status_var:
                return ""
            status_jvar = to_java_var(status_var)
            if redefines_layout and status_var.upper() in redefines_layout:
                return f"set_{status_jvar}(\"{val}\");"
            else:
                return f"{status_jvar} = \"{val}\";"

        lines = []
        if organization == "INDEXED":
            key_start = 0
            key_end = curr
            if record_key:
                for f_name, start, end in offsets:
                    if f_name.upper() == record_key.upper():
                        key_start = start
                        key_end = end
                        break
            
            lines.append(f"    private java.util.Map<String, String> {java_fd}_records = new java.util.LinkedHashMap<>();")
            lines.append(f"    private java.util.Iterator<String> {java_fd}_iterator;")
            lines.append("")
            
            lines.append(f"    private void save_{java_fd}() {{")
            lines.append(f"        try {{")
            lines.append(f"            java.nio.file.Path p = Paths.get(\"{assign_path}\");")
            lines.append(f"            if (p.getParent() != null) Files.createDirectories(p.getParent());")
            lines.append(f"            try (BufferedWriter w = Files.newBufferedWriter(p)) {{")
            lines.append(f"                for (String line : {java_fd}_records.values()) {{")
            lines.append(f"                    w.write(line);")
            lines.append(f"                    w.newLine();")
            lines.append(f"                }}")
            lines.append(f"            }}")
            lines.append(f"        }} catch (IOException e) {{")
            lines.append(f"            throw new RuntimeException(e);")
            lines.append(f"        }}")
            lines.append(f"    }}")
            lines.append("")
            
            lines.append(f"    private void open_{java_fd}() {{")
            lines.append(f"        try {{")
            lines.append(f"            {java_fd}_records.clear();")
            lines.append(f"            java.nio.file.Path p = Paths.get(\"{assign_path}\");")
            lines.append(f"            if (Files.exists(p)) {{")
            lines.append(f"                try (BufferedReader r = Files.newBufferedReader(p)) {{")
            lines.append(f"                    String line;")
            lines.append(f"                    while ((line = r.readLine()) != null) {{")
            lines.append(f"                        if (line.length() >= {key_end}) {{")
            lines.append(f"                            String key = line.substring({key_start}, {key_end}).trim();")
            lines.append(f"                            {java_fd}_records.put(key, line);")
            lines.append(f"                        }}")
            lines.append(f"                    }}")
            lines.append(f"                }}")
            lines.append(f"            }}")
            lines.append(f"            {java_fd}_iterator = {java_fd}_records.values().iterator();")
            status_ok = get_status_assign("00")
            if status_ok: lines.append(f"            {status_ok}")
            lines.append(f"        }} catch (IOException e) {{")
            status_err = get_status_assign("35")
            if status_err:
                lines.append(f"            {status_err}")
            else:
                lines.append(f"            throw new RuntimeException(e);")
            lines.append(f"        }}")
            lines.append(f"    }}")
            lines.append("")
            
            lines.append(f"    private void populate_{java_fd}_fields(String line) {{")
            if redefined_record_name:
                java_rec = to_java_var(redefined_record_name)
                backing_var = f"{java_rec}_backing"
                lines.append(f"        String padded = String.format(\"%-\" + {redefined_record_len} + \"s\", line);")
                lines.append(f"        if (padded.length() > {redefined_record_len}) padded = padded.substring(0, {redefined_record_len});")
                lines.append(f"        for (int i = 0; i < {redefined_record_len}; i++) {{")
                lines.append(f"            {backing_var}[i] = padded.charAt(i);")
                lines.append(f"        }}")
            else:
                for f_name, start, end in offsets:
                    java_var = to_java_var(f_name)
                    pic = [p for n, p in record_fields if n == f_name][0]
                    java_type = NativeTypeMapper.get_java_type(pic)
                    lines.append(f"        if (line.length() >= {end}) {{")
                    lines.append(f"            String val = line.substring({start}, {end}).trim();")
                    if java_type == "BigDecimal":
                        scale = NativeTypeMapper.parse_pic(pic)[2]
                        signed = NativeTypeMapper.parse_pic(pic)[3]
                        if signed:
                            lines.append(f"            {java_var} = parseSigned(val, {scale});")
                        else:
                            lines.append(f"            {java_var} = val.isEmpty() ? BigDecimal.ZERO : new BigDecimal(val).movePointLeft({scale});")
                    elif java_type in ("Integer", "Long"):
                        signed = NativeTypeMapper.parse_pic(pic)[3]
                        t_cast = "int" if java_type == "Integer" else "long"
                        if signed:
                            lines.append(f"            {java_var} = ({t_cast}) parseSignedLong(val);")
                        else:
                            parse_call = "Integer.parseInt(val)" if java_type == "Integer" else "Long.parseLong(val)"
                            zero_val = "0" if java_type == "Integer" else "0L"
                            lines.append(f"            {java_var} = val.isEmpty() ? {zero_val} : {parse_call};")
                    else:
                        lines.append(f"            {java_var} = val;")
                    lines.append(f"        }}")
            lines.append(f"    }}")
            lines.append("")
            
            lines.append(f"    private String format_{java_fd}_record() {{")
            if redefined_record_name:
                java_rec = to_java_var(redefined_record_name)
                backing_var = f"{java_rec}_backing"
                lines.append(f"        return new String({backing_var});")
            else:
                fmt_parts = []
                fmt_args = []
                for f_name, pic in record_fields:
                    java_var = to_java_var(f_name)
                    java_type = NativeTypeMapper.get_java_type(pic)
                    _, length, scale, signed = NativeTypeMapper.parse_pic(pic)
                    if java_type == "BigDecimal":
                        fmt_parts.append(f"%0{length}d")
                        fmt_args.append(f"({java_var}.movePointRight({scale}).longValue())")
                    elif java_type in ("Integer", "Long"):
                        if signed:
                            fmt_parts.append(f"%{length}s")
                            fmt_args.append(f"formatSigned({java_var}, {length}, true)")
                        else:
                            fmt_parts.append(f"%0{length}d")
                            fmt_args.append(java_var)
                    else:
                        fmt_parts.append(f"%-{length}s")
                        fmt_args.append(java_var)
                fmt_str = "".join(fmt_parts)
                args_str = ", ".join(fmt_args)
                lines.append(f"        return String.format(\"{fmt_str}\", {args_str});")
            lines.append(f"    }}")
            lines.append("")
            
            lines.append(f"    private boolean read_{java_fd}() {{")
            lines.append(f"        if ({java_fd}_iterator == null) {{")
            lines.append(f"            {java_fd}_iterator = {java_fd}_records.values().iterator();")
            lines.append(f"        }}")
            lines.append(f"        if (!{java_fd}_iterator.hasNext()) {{")
            status_eof = get_status_assign("10")
            if status_eof: lines.append(f"            {status_eof}")
            lines.append(f"            return false;")
            lines.append(f"        }}")
            lines.append(f"        String line = {java_fd}_iterator.next();")
            lines.append(f"        populate_{java_fd}_fields(line);")
            status_ok = get_status_assign("00")
            if status_ok: lines.append(f"        {status_ok}")
            lines.append(f"        return true;")
            lines.append(f"    }}")
            lines.append("")
            
            lines.append(f"    private boolean read_{java_fd}_key(String key) {{")
            lines.append(f"        String line = {java_fd}_records.get(key.trim());")
            lines.append(f"        if (line == null) {{")
            status_err = get_status_assign("23")
            if status_err: lines.append(f"            {status_err}")
            lines.append(f"            return false;")
            lines.append(f"        }}")
            lines.append(f"        populate_{java_fd}_fields(line);")
            status_ok = get_status_assign("00")
            if status_ok: lines.append(f"        {status_ok}")
            lines.append(f"        return true;")
            lines.append(f"    }}")
            lines.append("")
            
            lines.append(f"    private boolean write_{java_fd}() {{")
            lines.append(f"        String line = format_{java_fd}_record();")
            lines.append(f"        if (line.length() >= {key_end}) {{")
            lines.append(f"            String key = line.substring({key_start}, {key_end}).trim();")
            lines.append(f"            if ({java_fd}_records.containsKey(key)) {{")
            status_dup = get_status_assign("22")
            if status_dup: lines.append(f"                {status_dup}")
            lines.append(f"                return false;")
            lines.append(f"            }}")
            lines.append(f"            {java_fd}_records.put(key, line);")
            lines.append(f"            save_{java_fd}();")
            status_ok = get_status_assign("00")
            if status_ok: lines.append(f"            {status_ok}")
            lines.append(f"            return true;")
            lines.append(f"        }}")
            lines.append(f"        return false;")
            lines.append(f"    }}")
            lines.append("")
            
            lines.append(f"    private boolean rewrite_{java_fd}() {{")
            lines.append(f"        String line = format_{java_fd}_record();")
            lines.append(f"        if (line.length() >= {key_end}) {{")
            lines.append(f"            String key = line.substring({key_start}, {key_end}).trim();")
            lines.append(f"            if (!{java_fd}_records.containsKey(key)) {{")
            status_miss = get_status_assign("23")
            if status_miss: lines.append(f"                {status_miss}")
            lines.append(f"                return false;")
            lines.append(f"            }}")
            lines.append(f"            {java_fd}_records.put(key, line);")
            lines.append(f"            save_{java_fd}();")
            status_ok = get_status_assign("00")
            if status_ok: lines.append(f"            {status_ok}")
            lines.append(f"            return true;")
            lines.append(f"        }}")
            lines.append(f"        return false;")
            lines.append(f"    }}")
            lines.append("")
            
            lines.append(f"    private void close_{java_fd}() {{")
            lines.append(f"        save_{java_fd}();")
            lines.append(f"        {java_fd}_records.clear();")
            lines.append(f"        {java_fd}_iterator = null;")
            status_ok = get_status_assign("00")
            if status_ok: lines.append(f"        {status_ok}")
            lines.append(f"    }}")
            
        else:
            if is_input:
                lines.append(f"    private BufferedReader {java_fd}_reader;")
                lines.append(f"    private void open_{java_fd}() {{")
                lines.append(f"        try {{")
                lines.append(f"            {java_fd}_reader = Files.newBufferedReader(Paths.get(\"{assign_path}\"));")
                status_ok = get_status_assign("00")
                if status_ok: lines.append(f"            {status_ok}")
                lines.append(f"        }} catch (IOException e) {{")
                status_err = get_status_assign("35")
                if status_err:
                    lines.append(f"            {status_err}")
                else:
                    lines.append(f"            throw new RuntimeException(e);")
                lines.append(f"        }}")
                lines.append(f"    }}")
                lines.append("")
                lines.append(f"    private boolean read_{java_fd}() {{")
                lines.append(f"        try {{")
                lines.append(f"            String line = {java_fd}_reader.readLine();")
                lines.append(f"            if (line == null) {{")
                status_eof = get_status_assign("10")
                if status_eof: lines.append(f"                {status_eof}")
                lines.append(f"                return false;")
                lines.append(f"            }} else {{")
                if redefined_record_name:
                    java_rec = to_java_var(redefined_record_name)
                    backing_var = f"{java_rec}_backing"
                    lines.append(f"                String padded = String.format(\"%-\" + {redefined_record_len} + \"s\", line);")
                    lines.append(f"                if (padded.length() > {redefined_record_len}) padded = padded.substring(0, {redefined_record_len});")
                    lines.append(f"                for (int i = 0; i < {redefined_record_len}; i++) {{")
                    lines.append(f"                    {backing_var}[i] = padded.charAt(i);")
                    lines.append(f"                }}")
                else:
                    for f_name, start, end in offsets:
                        java_var = to_java_var(f_name)
                        pic = [p for n, p in record_fields if n == f_name][0]
                        java_type = NativeTypeMapper.get_java_type(pic)
                        
                        lines.append(f"                if (line.length() >= {end}) {{")
                        lines.append(f"                    String val = line.substring({start}, {end}).trim();")
                        if java_type == "BigDecimal":
                            scale = NativeTypeMapper.parse_pic(pic)[2]
                            signed = NativeTypeMapper.parse_pic(pic)[3]
                            if signed:
                                lines.append(f"                    {java_var} = parseSigned(val, {scale});")
                            else:
                                lines.append(f"                    {java_var} = val.isEmpty() ? BigDecimal.ZERO : new BigDecimal(val).movePointLeft({scale});")
                        elif java_type in ("Integer", "Long"):
                            signed = NativeTypeMapper.parse_pic(pic)[3]
                            t_cast = "int" if java_type == "Integer" else "long"
                            if signed:
                                lines.append(f"                    {java_var} = ({t_cast}) parseSignedLong(val);")
                            else:
                                parse_call = "Integer.parseInt(val)" if java_type == "Integer" else "Long.parseLong(val)"
                                zero_val = "0" if java_type == "Integer" else "0L"
                                lines.append(f"                    {java_var} = val.isEmpty() ? {zero_val} : {parse_call};")
                        else:
                            lines.append(f"                    {java_var} = val;")
                        lines.append(f"                }}")
                status_ok = get_status_assign("00")
                if status_ok: lines.append(f"                {status_ok}")
                lines.append(f"            }}")
                lines.append(f"            return true;")
                lines.append(f"        }} catch (IOException e) {{")
                status_err = get_status_assign("30")
                if status_err: lines.append(f"            {status_err}")
                lines.append(f"            return false;")
                lines.append(f"        }}")
                lines.append(f"    }}")
                lines.append("")
                lines.append(f"    private void close_{java_fd}() {{")
                lines.append(f"        try {{")
                lines.append(f"            if ({java_fd}_reader != null) {java_fd}_reader.close();")
                status_ok = get_status_assign("00")
                if status_ok: lines.append(f"            {status_ok}")
                lines.append(f"        }} catch (IOException e) {{")
                status_err = get_status_assign("30")
                if status_err: lines.append(f"            {status_err}")
                lines.append(f"        }}")
                lines.append(f"    }}")
            else:
                lines.append(f"    private BufferedWriter {java_fd}_writer;")
                lines.append(f"    private void open_{java_fd}() {{")
                lines.append(f"        try {{")
                lines.append(f"            java.nio.file.Path parent = Paths.get(\"{assign_path}\").getParent();")
                lines.append(f"            if (parent != null) Files.createDirectories(parent);")
                lines.append(f"            {java_fd}_writer = Files.newBufferedWriter(Paths.get(\"{assign_path}\"));")
                status_ok = get_status_assign("00")
                if status_ok: lines.append(f"            {status_ok}")
                lines.append(f"        }} catch (IOException e) {{")
                status_err = get_status_assign("30")
                if status_err:
                    lines.append(f"            {status_err}")
                else:
                    lines.append(f"            throw new RuntimeException(e);")
                lines.append(f"        }}")
                lines.append(f"    }}")
                lines.append("")
                lines.append(f"    private void write_{java_fd}() {{")
                lines.append(f"        try {{")
                if redefined_record_name:
                    java_rec = to_java_var(redefined_record_name)
                    backing_var = f"{java_rec}_backing"
                    lines.append(f"            {java_fd}_writer.write({backing_var});")
                else:
                    fmt_parts = []
                    fmt_args = []
                    for f_name, pic in record_fields:
                        java_var = to_java_var(f_name)
                        java_type = NativeTypeMapper.get_java_type(pic)
                        _, length, scale, signed = NativeTypeMapper.parse_pic(pic)
                        if java_type == "BigDecimal":
                            fmt_parts.append(f"%0{length}d")
                            fmt_args.append(f"({java_var}.movePointRight({scale}).longValue())")
                        elif java_type in ("Integer", "Long"):
                            if signed:
                                fmt_parts.append(f"%{length}s")
                                fmt_args.append(f"formatSigned({java_var}, {length}, true)")
                            else:
                                fmt_parts.append(f"%0{length}d")
                                fmt_args.append(java_var)
                        else:
                            fmt_parts.append(f"%-{length}s")
                            fmt_args.append(java_var)
                    fmt_str = "".join(fmt_parts)
                    args_str = ", ".join(fmt_args)
                    lines.append(f"            {java_fd}_writer.write(String.format(\"{fmt_str}\", {args_str}));")
                lines.append(f"            {java_fd}_writer.newLine();")
                status_ok = get_status_assign("00")
                if status_ok: lines.append(f"            {status_ok}")
                lines.append(f"        }} catch (IOException e) {{")
                status_err = get_status_assign("30")
                if status_err: lines.append(f"            {status_err}")
                lines.append(f"        }}")
                lines.append(f"    }}")
                lines.append("")
                lines.append(f"    private void close_{java_fd}() {{")
                lines.append(f"        try {{")
                lines.append(f"            if ({java_fd}_writer != null) {java_fd}_writer.close();")
                status_ok = get_status_assign("00")
                if status_ok: lines.append(f"            {status_ok}")
                lines.append(f"        }} catch (IOException e) {{")
                status_err = get_status_assign("30")
                if status_err: lines.append(f"            {status_err}")
                lines.append(f"        }}")
                lines.append(f"    }}")
            
        return "\n".join(lines)

class NativeProgramGenerator:
    def __init__(self, program_name: str, ir_nodes: list, file_assigns: list = None):
        self.program_name = program_name
        self.ir_nodes = ir_nodes
        self.file_assigns = file_assigns or []
        
        self.var_types = {}
        self.var_pics = {}
        self.fd_fields = {}
        self.record_to_fd = {}
        self.group_fields = {}
        self.using_args = []
        # level88_map: {condition_name: (parent_name, [values])}
        self.level88_map = {}
        # occurs_map: {array_var_name: (size, elem_java_type)}
        self.occurs_map = {}
        self.next_section_map = {}
        self.diagnostics = []
        self.paragraphs = {}
        self.para_names = []
        self.redefines_layout = {}
        self.redefined_records_backing = {}
        self.occurs_depending_on = {}
        
        self.file_status_vars = {}
        self.file_orgs = {}
        self.file_access_modes = {}
        self.file_keys = {}
        
        self._build_mappings()

    def _build_mappings(self):
        sorted_nodes = sorted(self.ir_nodes, key=lambda n: n.source_line)
        self._analyze_redefines_and_layout(sorted_nodes)
        
        # Collect FILE_CONTROL info
        select_files = {}
        for n in sorted_nodes:
            if n.kind == "FILE_CONTROL":
                f_name = n.properties.get("file_name", "").upper()
                status_var = n.properties.get("status_var")
                org = n.properties.get("organization", "SEQUENTIAL")
                mode = n.properties.get("access_mode", "SEQUENTIAL")
                key = n.properties.get("record_key")
                assign_name = n.properties.get("assign_name", "")
                
                if status_var:
                    self.file_status_vars[f_name] = status_var
                self.file_orgs[f_name] = org
                self.file_access_modes[f_name] = mode
                if key:
                    self.file_keys[f_name] = key
                select_files[f_name] = {
                    "assign_name": assign_name,
                    "organization": org
                }
                
        # Determine is_input based on OPEN statements
        file_io_modes = {}
        for n in sorted_nodes:
            if n.kind == "STATEMENT" and n.properties.get("statement_type") == "OPEN":
                targets = n.properties.get("targets", [])
                curr_mode = "INPUT"
                for t in targets:
                    if t in ("INPUT", "OUTPUT", "I-O", "EXTEND"):
                        curr_mode = t
                    else:
                        file_io_modes[t.upper()] = curr_mode
                        
        if not self.file_assigns:
            for f_name, info in select_files.items():
                assign_name = info["assign_name"]
                if assign_name:
                    if assign_name.startswith("'") or assign_name.startswith('"'):
                        assign_path = assign_name[1:-1]
                    else:
                        assign_path = assign_name
                else:
                    assign_path = f_name.lower() + ".dat"
                
                mode = file_io_modes.get(f_name, "INPUT")
                is_input = (mode != "OUTPUT")
                self.file_assigns.append({
                    "logical_name": f_name,
                    "physical_path": assign_path,
                    "is_input": is_input
                })
        print("SELECT FILES:", select_files)
        print("FILE ASSIGNS:", self.file_assigns)
        
        # Populate using_args
        for n in sorted_nodes:
            if n.kind == "DIVISION" and n.properties.get("name") == "PROCEDURE":
                self.using_args = n.properties.get("using_args", [])
                break

        last_non88 = None   # track parent of 88 conditions
        for n in sorted_nodes:
            props = n.properties
            kind = n.kind
            if kind in ("VARIABLE", "DATA_ITEM"):
                name = props.get("name", "")
                pic = props.get("picture", "")
                usage = props.get("usage", "")
                level = props.get("level", 1)
                is_group = props.get("is_group", False)
                if level == 88:
                    # Level-88 condition: map to parent
                    values = props.get("condition_values", [])
                    parent = last_non88 if last_non88 else ""
                    self.level88_map[name] = (parent, values)
                else:
                    if name:
                        last_non88 = name
                    if name:
                        if pic:
                            self.var_types[name] = NativeTypeMapper.get_java_type(pic, usage)
                            self.var_pics[name] = pic
                        elif is_group:
                            self.var_types[name] = "String"
                            self.var_pics[name] = ""
                    # OCCURS table
                    occurs = props.get("occurs", 0)
                    is_array = False
                    if name in self.redefines_layout:
                        is_array = self.redefines_layout[name]["is_array"]
                        occurs = self.redefines_layout[name]["occurs_max"]
                    if name and (occurs or is_array):
                        elem_type = NativeTypeMapper.get_java_type(pic, usage) if pic else "String"
                        self.occurs_map[name] = (int(occurs) if occurs else 1, elem_type)

        # Populate group_fields
        current_group = None
        for n in sorted_nodes:
            if n.kind in ("VARIABLE", "DATA_ITEM"):
                name = n.properties.get("name", "")
                level = n.properties.get("level", 1)
                is_group = n.properties.get("is_group", False)
                if level == 1:
                    if is_group:
                        current_group = name.upper()
                        self.group_fields[current_group] = []
                    else:
                        current_group = None
                elif level > 1 and current_group:
                    self.group_fields[current_group].append(name)

        in_file_section = False
        file_records = []
        curr_record_fields = []
        record_names = []
        
        for n in sorted_nodes:
            props = n.properties
            kind = n.kind
            if kind == "SECTION":
                sec_name = props.get("name", "").upper()
                if sec_name == "FILE":
                    in_file_section = True
                elif sec_name == "WORKING-STORAGE":
                    in_file_section = False
                    if curr_record_fields:
                        file_records.append(curr_record_fields)
                        curr_record_fields = []
                        
            elif in_file_section and kind in ("VARIABLE", "DATA_ITEM"):
                name = props.get("name", "")
                level = props.get("level", 1)
                pic = props.get("picture", "")
                
                if level == 1:
                    if curr_record_fields:
                        file_records.append(curr_record_fields)
                    curr_record_fields = []
                    record_names.append(name)
                    if pic:
                        curr_record_fields.append((name, pic))
                elif level > 1 and name and pic:
                    curr_record_fields.append((name, pic))
                    
        if curr_record_fields:
            file_records.append(curr_record_fields)

        for i, assign in enumerate(self.file_assigns):
            logical = assign.get("logical_name", "")
            if i < len(file_records):
                self.fd_fields[logical] = file_records[i]
                if i < len(record_names):
                    self.record_to_fd[record_names[i]] = logical
            else:
                self.fd_fields[logical] = []

        # Populate next_section_map
        sections = []
        for n in sorted_nodes:
            if n.kind == "SECTION":
                sections.append(to_java_var(n.properties.get("name", "")))
        
        current_section = None
        for n in sorted_nodes:
            if n.kind == "SECTION":
                current_section = to_java_var(n.properties.get("name", ""))
            
            if n.kind in ("PARAGRAPH", "SECTION"):
                name = to_java_var(n.properties.get("name", ""))
                next_sec = None
                if current_section:
                    try:
                        idx = sections.index(current_section)
                        if idx + 1 < len(sections):
                            next_sec = sections[idx + 1]
                    except ValueError:
                        pass
                else:
                    if sections:
                        next_sec = sections[0]
                self.next_section_map[name] = next_sec

    def _analyze_redefines_and_layout(self, sorted_nodes):
        records = []
        current_record = []
        has_redefines_or_odo = False
        
        for n in sorted_nodes:
            if n.kind in ("VARIABLE", "DATA_ITEM"):
                lvl = n.properties.get("level", 1)
                if lvl == 88:
                    continue
                if lvl == 1:
                    if current_record:
                        records.append((current_record, has_redefines_or_odo))
                    current_record = [n]
                    has_redefines_or_odo = False
                else:
                    if current_record:
                        current_record.append(n)
                        if n.properties.get("redefines") or n.properties.get("depending_on"):
                            has_redefines_or_odo = True
                            
        if current_record:
            records.append((current_record, has_redefines_or_odo))
            
        for rec_nodes, is_special in records:
            if not rec_nodes:
                continue
            root_node = rec_nodes[0]
            root_name = root_node.properties.get("name")
            
            root_layout, nodes_map = self._build_layout_tree(rec_nodes)
            if not root_layout:
                continue
                
            self._inherit_occurs(root_layout)
            total_len = self._compute_layout_offsets(root_layout)
            
            record_has_redef = any(node.properties.get("redefines") is not None for node in rec_nodes)
            
            if record_has_redef:
                self.redefined_records_backing[root_name] = total_len
                
            for name, layout_node in nodes_map.items():
                if layout_node.depending_on:
                    self.occurs_depending_on[name] = (
                        layout_node.depending_on,
                        layout_node.occurs_min if layout_node.occurs_min is not None else 1,
                        layout_node.occurs_max if layout_node.occurs_max is not None else layout_node.occurs
                    )
                
                if record_has_redef:
                    usage = layout_node.usage or ""
                    if usage in ("COMP", "COMP-3", "BINARY", "PACKED-DECIMAL"):
                        diag = {
                            "construct": "REDEFINES",
                            "source_coordinate": f"{self.program_name}:{layout_node.name}",
                            "reason": f"Unsupported binary storage representation {usage} in redefines group",
                            "severity": "ERROR",
                            "status": "NATIVE_TRANSLATION_BLOCKED"
                        }
                        self.diagnostics.append(diag)
                        
                    java_type = "String"
                    pic = layout_node.pic
                    scale = 0
                    signed = False
                    if pic:
                        java_type = NativeTypeMapper.get_java_type(pic, layout_node.usage)
                        _, _, scale, signed = NativeTypeMapper.parse_pic(pic)
                    elif layout_node.children:
                        java_type = "String"
                        
                    occurs_step = layout_node.length
                    if layout_node.occurs and layout_node.occurs > 1:
                        occurs_step = layout_node.length // layout_node.occurs
                    parent_occurs = False
                    p = layout_node.parent
                    while p:
                        if p.occurs and p.occurs > 1:
                            parent_occurs = True
                            occurs_step = p.length // p.occurs
                            break
                        p = p.parent
                        
                    is_array = len(layout_node.occurs_list) >= 1
                    
                    self.redefines_layout[name] = {
                        "offset": layout_node.offset,
                        "length": layout_node.length,
                        "type": java_type,
                        "scale": scale,
                        "signed": signed,
                        "record_name": root_name,
                        "is_array": is_array,
                        "occurs_step": occurs_step,
                        "occurs_max": layout_node.occurs_max or layout_node.occurs or 1,
                        "depending_on": layout_node.depending_on
                    }

    def _build_layout_tree(self, data_items):
        root = None
        stack = []
        nodes_map = {}
        
        for item in data_items:
            props = item.properties
            name = props.get("name")
            lvl = props.get("level", 1)
            
            node = LayoutNode(name, lvl)
            node.pic = props.get("picture")
            node.usage = props.get("usage")
            node.occurs = props.get("occurs")
            node.occurs_min = props.get("occurs_min")
            node.occurs_max = props.get("occurs_max")
            node.depending_on = props.get("depending_on")
            node.redefines = props.get("redefines")
            
            nodes_map[name] = node
            
            if lvl == 1:
                root = node
                stack = [root]
            else:
                while stack and stack[-1].level >= lvl:
                    stack.pop()
                if stack:
                    parent = stack[-1]
                    node.parent = parent
                    parent.children.append(node)
                stack.append(node)
                
        return root, nodes_map

    def _inherit_occurs(self, node, current_occurs=None):
        if current_occurs:
            node.occurs_list = current_occurs + ([node.occurs] if node.occurs else [])
        else:
            node.occurs_list = [node.occurs] if node.occurs else []
            
        for child in node.children:
            self._inherit_occurs(child, node.occurs_list)

    def _compute_layout_offsets(self, node, current_offset=0):
        node.offset = current_offset
        
        if not node.children:
            if node.pic:
                _, base_len, _, _ = NativeTypeMapper.parse_pic(node.pic)
            else:
                base_len = 0
            occurs = node.occurs if node.occurs else 1
            node.length = base_len * occurs
            return node.length
        else:
            max_child_end = current_offset
            curr = current_offset
            
            for child in node.children:
                if child.redefines:
                    ref_node = None
                    for sib in node.children:
                        if sib.name == child.redefines:
                            ref_node = sib
                            break
                    if ref_node:
                        child_len = self._compute_layout_offsets(child, ref_node.offset)
                        max_child_end = max(max_child_end, ref_node.offset + child_len)
                    else:
                        child_len = self._compute_layout_offsets(child, curr)
                        curr += child_len
                        max_child_end = max(max_child_end, curr)
                else:
                    curr = max_child_end
                    child_len = self._compute_layout_offsets(child, curr)
                    max_child_end = max(max_child_end, curr + child_len)
                    
            occurs = node.occurs if node.occurs else 1
            group_base_len = max_child_end - current_offset
            node.length = group_base_len * occurs
            return node.length

    def _get_var_line(self, var_name: str) -> int:
        for n in self.ir_nodes:
            if n.kind in ("VARIABLE", "DATA_ITEM") and n.properties.get("name") == var_name:
                return n.source_line
        return 9999

    def _generate_redefines_storage(self) -> list:
        lines = []
        if not self.redefined_records_backing:
            return lines
            
        lines.append("    // --- REDEFINES Backing Storage ---")
        for rec_name, length in self.redefined_records_backing.items():
            backing_var = to_java_var(rec_name) + "_backing"
            lines.append(f"    private final char[] {backing_var} = new char[{length}];")
            lines.append(f"    {{")
            lines.append(f"        java.util.Arrays.fill({backing_var}, ' ');")
            lines.append(f"    }}")
            lines.append("")
            
        lines.append("    // --- REDEFINES Accessors ---")
        for v, layout in self.redefines_layout.items():
            java_var = to_java_var(v)
            offset = layout["offset"]
            length = layout["length"]
            java_type = layout["type"]
            backing_var = to_java_var(layout["record_name"]) + "_backing"
            scale = layout["scale"]
            signed = "true" if layout["signed"] else "false"
            is_array = layout["is_array"]
            occurs_step = layout["occurs_step"]
            
            # --- GETTER ---
            if is_array:
                lines.append(f"    public {java_type} get_{java_var}(int idx) {{")
                lines.append(f"        int off = {offset} + (idx - 1) * {occurs_step};")
            else:
                lines.append(f"    public {java_type} get_{java_var}() {{")
                lines.append(f"        int off = {offset};")
                
            if java_type == "String":
                lines.append(f"        return new String({backing_var}, off, {length});")
            elif java_type == "BigDecimal":
                lines.append(f"        String s = new String({backing_var}, off, {length}).trim();")
                lines.append(f"        return parseSigned(s, {scale});")
            else:
                cast = "int" if java_type == "Integer" else "long"
                lines.append(f"        String s = new String({backing_var}, off, {length}).trim();")
                lines.append(f"        return ({cast}) parseSignedLong(s);")
            lines.append("    }")
            lines.append("")
            
            # --- SETTER ---
            if is_array:
                lines.append(f"    public void set_{java_var}(int idx, {java_type} val) {{")
                lines.append(f"        int off = {offset} + (idx - 1) * {occurs_step};")
            else:
                lines.append(f"    public void set_{java_var}({java_type} val) {{")
                lines.append(f"        int off = {offset};")
                
            if java_type == "String":
                lines.append(f"        if (val == null) val = \"\";")
                lines.append(f"        String padded = String.format(\"%-\" + {length} + \"s\", val);")
                lines.append(f"        if (padded.length() > {length}) padded = padded.substring(0, {length});")
                lines.append(f"        for (int i = 0; i < {length}; i++) {{")
                lines.append(f"            {backing_var}[off + i] = padded.charAt(i);")
                lines.append(f"        }}")
            elif java_type == "BigDecimal":
                lines.append(f"        if (val == null) val = BigDecimal.ZERO;")
                lines.append(f"        long unscaled = val.movePointRight({scale}).longValue();")
                lines.append(f"        String formatted = formatSigned(unscaled, {length}, {signed});")
                lines.append(f"        for (int i = 0; i < {length}; i++) {{")
                lines.append(f"            {backing_var}[off + i] = formatted.charAt(i);")
                lines.append(f"        }}")
            else:
                lines.append(f"        String formatted = formatSigned(val, {length}, {signed});")
                lines.append(f"        for (int i = 0; i < {length}; i++) {{")
                lines.append(f"            {backing_var}[off + i] = formatted.charAt(i);")
                lines.append(f"        }}")
            lines.append("    }")
            lines.append("")
            
        return lines

    def generate_class_source(self, all_generators: dict = None) -> str:
        class_name = to_java_class(self.program_name)
        
        lines = []
        lines.append("package com.systema.modernized.native_gen;")
        lines.append("")
        lines.append("import java.io.BufferedReader;")
        lines.append("import java.io.BufferedWriter;")
        lines.append("import java.io.IOException;")
        lines.append("import java.math.BigDecimal;")
        lines.append("import java.math.RoundingMode;")
        lines.append("import java.nio.file.Files;")
        lines.append("import java.nio.file.Paths;")
        lines.append("import java.util.Objects;")
        lines.append("")
        lines.append(f"public class {class_name} {{")
        lines.append("")
        
        for v, java_type in self.var_types.items():
            if v in self.occurs_map or v in self.redefines_layout:
                continue
            java_var = to_java_var(v)
            initial_val = None
            for n in self.ir_nodes:
                if n.kind in ("VARIABLE", "DATA_ITEM") and n.properties.get("name") == v:
                    initial_val = n.properties.get("value")
                    break
            
            if initial_val is not None:
                initial_val = str(initial_val).strip()
                if initial_val.upper() in ("ZERO", "ZEROS", "ZEROES"):
                    if java_type == "BigDecimal":
                        lines.append(f"    public BigDecimal {java_var} = BigDecimal.ZERO;")
                    elif java_type in ("Integer", "Long"):
                        t_prim = "int" if java_type == "Integer" else "long"
                        lines.append(f"    public {t_prim} {java_var} = 0;")
                    else:
                        pic = self.var_pics.get(v, "")
                        if pic:
                            _, length, _, _ = NativeTypeMapper.parse_pic(pic)
                            padded_val = "0".ljust(length)
                        else:
                            padded_val = "0"
                        lines.append(f"    public String {java_var} = \"{padded_val}\";")
                elif initial_val.upper() in ("SPACE", "SPACES"):
                    pic = self.var_pics.get(v, "")
                    if pic:
                        _, length, _, _ = NativeTypeMapper.parse_pic(pic)
                        padded_val = "".ljust(length)
                    else:
                        padded_val = ""
                    lines.append(f"    public String {java_var} = \"{padded_val}\";")
                else:
                    if (initial_val.startswith("'") and initial_val.endswith("'")) or \
                       (initial_val.startswith('"') and initial_val.endswith('"')):
                        initial_val = initial_val[1:-1]
                    
                    if java_type == "BigDecimal":
                        lines.append(f"    public BigDecimal {java_var} = new BigDecimal(\"{initial_val}\");")
                    elif java_type in ("Integer", "Long"):
                        cleaned_val = re.sub(r'[^\d\-]', '', initial_val)
                        if not cleaned_val:
                            cleaned_val = "0"
                        t_prim = "int" if java_type == "Integer" else "long"
                        lines.append(f"    public {t_prim} {java_var} = {cleaned_val};")
                    else:
                        pic = self.var_pics.get(v, "")
                        if pic:
                            _, length, _, _ = NativeTypeMapper.parse_pic(pic)
                            padded_val = initial_val.ljust(length)
                        else:
                            padded_val = initial_val
                        lines.append(f"    public String {java_var} = \"{padded_val}\";")
            else:
                if java_type == "BigDecimal":
                    lines.append(f"    public BigDecimal {java_var} = BigDecimal.ZERO;")
                elif java_type in ("Integer", "Long"):
                    t_prim = "int" if java_type == "Integer" else "long"
                    lines.append(f"    public {t_prim} {java_var} = 0;")
                else:
                    pic = self.var_pics.get(v, "")
                    if pic:
                        _, length, _, _ = NativeTypeMapper.parse_pic(pic)
                        padded_val = "".ljust(length)
                    else:
                        padded_val = ""
                    lines.append(f"    public String {java_var} = \"{padded_val}\";")
        
        # Emit OCCURS array fields (skip scalars already emitted above)
        for arr_name, (arr_size, elem_type) in self.occurs_map.items():
            if arr_name in self.redefines_layout:
                continue
            java_arr = to_java_var(arr_name)
            if elem_type == "BigDecimal":
                lines.append(f"    public BigDecimal[] {java_arr} = new BigDecimal[{arr_size}];")
                lines.append(f"    {{  // initialise array elements")
                lines.append(f"        java.util.Arrays.fill({java_arr}, BigDecimal.ZERO);")
                lines.append(f"    }}")
            elif elem_type == "Integer":
                lines.append(f"    public int[] {java_arr} = new int[{arr_size}];")
            elif elem_type == "Long":
                lines.append(f"    public long[] {java_arr} = new long[{arr_size}];")
            else:
                lines.append(f"    public String[] {java_arr} = new String[{arr_size}];")
                lines.append(f"    {{  // initialise array elements")
                lines.append(f"        java.util.Arrays.fill({java_arr}, \"\");")
                lines.append(f"    }}")

        # Emit REDEFINES Storage & Accessors
        redefs_lines = self._generate_redefines_storage()
        lines.extend(redefs_lines)
        
        # Emit Initial value setter calls for redefines
        lines.append("    {  // Initialise redefines values")
        for v in self.redefines_layout.keys():
            initial_val = None
            for n in self.ir_nodes:
                if n.kind in ("VARIABLE", "DATA_ITEM") and n.properties.get("name") == v:
                    initial_val = n.properties.get("value")
                    break
            if initial_val is not None:
                initial_val = str(initial_val).strip()
                java_var = to_java_var(v)
                layout = self.redefines_layout[v]
                java_type = layout["type"]
                
                # Check for String quotes
                if (initial_val.startswith("'") and initial_val.endswith("'")) or \
                   (initial_val.startswith('"') and initial_val.endswith('"')):
                    initial_val = initial_val[1:-1]
                    
                if java_type == "BigDecimal":
                    lines.append(f"        set_{java_var}(new BigDecimal(\"{initial_val}\"));")
                elif java_type in ("Integer", "Long"):
                    cleaned_val = re.sub(r'[^\d\-]', '', initial_val)
                    if not cleaned_val:
                        cleaned_val = "0"
                    lines.append(f"        set_{java_var}({cleaned_val});")
                else:
                    lines.append(f"        set_{java_var}(\"{initial_val}\");")
        lines.append("    }")
        lines.append("")

        # Emit ODO bounds verification helper method
        lines.append("    private int checkBounds(int subscript, int minOccurs, String dependingVarName, int dependingVarValue) {")
        lines.append("        if (subscript < minOccurs || subscript > dependingVarValue) {")
        lines.append("            throw new IndexOutOfBoundsException(\"Subscript \" + subscript + \" out of active bounds [\" + minOccurs + \", \" + dependingVarValue + \"] depending on \" + dependingVarName);")
        lines.append("        }")
        lines.append("        return subscript - 1;")
        lines.append("    }")
        lines.append("")

        # Emit level-88 boolean helpers
        for cond_name, (parent_name, values) in self.level88_map.items():
            if not parent_name:
                continue
            method_name = to_java_method(cond_name)
            parent_java = to_java_var(parent_name)
            parent_type = self.var_types.get(parent_name, "String")
            if parent_name in self.redefines_layout:
                parent_expr = f"get_{parent_java}()"
            else:
                parent_expr = parent_java
            if parent_type == "BigDecimal":
                conds = " || ".join(
                    f"{parent_expr}.compareTo(new BigDecimal(\"{v}\")) == 0" for v in values
                )
            elif parent_type in ("Integer", "Long"):
                conds = " || ".join(f"{parent_expr} == {v}" for v in values)
            else:
                conds = " || ".join(f'Objects.equals({parent_expr}, "{v}")' for v in values)
            lines.append(f"    public boolean {method_name}() {{ return {conds}; }}")

        lines.append("")
        
        for assign in self.file_assigns:
            logical = assign.get("logical_name", "")
            path = assign.get("assign_path") or assign.get("physical_path") or ""
            is_input = is_input_file(logical, path)
            if logical not in self.fd_fields or not self.fd_fields[logical]:
                continue
            fields = self.fd_fields[logical]
            
            rec_name = None
            for r, fd in self.record_to_fd.items():
                if fd == logical:
                    rec_name = r
                    break
            redef_name = rec_name if (rec_name and rec_name in self.redefined_records_backing) else None
            redef_len = self.redefined_records_backing.get(redef_name) if redef_name else None
            org = self.file_orgs.get(logical.upper(), "SEQUENTIAL")
            key = self.file_keys.get(logical.upper())
            status_var = self.file_status_vars.get(logical.upper())
            
            lines.append(NativeFileIOGenerator.generate_io_methods(
                logical, path, is_input, fields,
                redefined_record_name=redef_name,
                redefined_record_len=redef_len,
                organization=org,
                record_key=key,
                status_var=status_var,
                redefines_layout=self.redefines_layout
            ))
            lines.append("")

        proc_nodes = [n for n in self.ir_nodes if n.kind == "STATEMENT"]
        
        paragraphs = {}
        curr_p = None
        in_procedure = False
        
        for n in self.ir_nodes:
            kind = n.kind
            if kind == "DIVISION" and n.properties.get("name") == "PROCEDURE":
                in_procedure = True
                continue
            if in_procedure:
                if kind in ("PARAGRAPH", "SECTION"):
                    curr_p = to_java_var(n.properties.get("name", ""))
                    paragraphs[curr_p] = []
                elif kind == "STATEMENT":
                    if curr_p is None:
                        curr_p = "main_process"
                        paragraphs[curr_p] = []
                    paragraphs[curr_p].append(n)

        # Build paragraph list in definition order
        self.paragraphs = paragraphs
        para_names = list(paragraphs.keys())
        if not para_names:
            para_names = ["main_process"]
            paragraphs["main_process"] = [n for n in self.ir_nodes if n.kind == "STATEMENT"]
        self.para_names = para_names
        total_paras = len(para_names)
            
        stmt_trans = NativeStatementTranslator(self.var_types, self.file_assigns, self.record_to_fd, all_generators=all_generators, current_generator=self, level88_map=self.level88_map)

        lines.append("    private boolean programExited = false;")
        lines.append("    private int nextParagraphIndex = -1;")
        lines.append("    private boolean skipToNextSentence = false;")
        lines.append(f"    private final int total_paras = {total_paras};")
        lines.append("")
        lines.append("    public static class StopRunException extends RuntimeException {}")
        lines.append("")
        
        lines.append("    private int getParagraphIndex(String name) {")
        lines.append("        if (name == null) return -1;")
        lines.append("        switch (name) {")
        for idx, p in enumerate(para_names):
            lines.append(f"            case \"{p}\": return {idx};")
        lines.append("            default: return -1;")
        lines.append("        }")
        lines.append("    }")
        lines.append("")

        lines.append("    private void runParagraph(int idx) {")
        lines.append("        if (programExited) return;")
        lines.append("        switch (idx) {")
        for idx, p in enumerate(para_names):
            lines.append(f"            case {idx}: {p}(); break;")
        lines.append("            default: break;")
        lines.append("        }")
        lines.append("    }")
        lines.append("")

        lines.append("    private void perform(String target, String thru) {")
        lines.append("        int startIdx = getParagraphIndex(target);")
        lines.append("        int endIdx = (thru != null) ? getParagraphIndex(thru) : startIdx;")
        lines.append("        if (startIdx == -1 || endIdx == -1 || startIdx > endIdx) return;")
        lines.append("        int i = startIdx;")
        lines.append("        while (i <= endIdx) {")
        lines.append("            if (programExited) return;")
        lines.append("            nextParagraphIndex = -1;")
        lines.append("            runParagraph(i);")
        lines.append("            if (nextParagraphIndex != -1) {")
        lines.append("                if (nextParagraphIndex >= startIdx && nextParagraphIndex <= endIdx) {")
        lines.append("                    i = nextParagraphIndex;")
        lines.append("                } else {")
        lines.append("                    return;")
        lines.append("                }")
        lines.append("            } else {")
        lines.append("                i++;")
        lines.append("            }")
        lines.append("        }")
        lines.append("    }")
        lines.append("")

        total_paras = len(para_names)
        lines.append("    public void execute() {")
        lines.append("        int i = 0;")
        lines.append(f"        while (i < {total_paras}) {{")
        lines.append("            if (programExited) break;")
        lines.append("            nextParagraphIndex = -1;")
        lines.append("            runParagraph(i);")
        lines.append("            if (nextParagraphIndex != -1) {")
        lines.append("                i = nextParagraphIndex;")
        lines.append("            } else {")
        lines.append("                i++;")
        lines.append("            }")
        lines.append("        }")
        lines.append("    }")
        lines.append("")

        for p_name, stmts in paragraphs.items():
            self.current_paragraph = p_name
            lines.append(f"    private void {p_name}() {{")
            skip_loop = False
            last_sentence_id = None
            for s in stmts:
                props = s.properties if hasattr(s, "properties") else s.get("properties", {})
                stype = props.get("statement_type", "").upper()
                
                sentence_id = props.get("sentence_id")
                if sentence_id is not None and sentence_id != last_sentence_id:
                    lines.append("        skipToNextSentence = false;")
                    last_sentence_id = sentence_id
                
                if stype in ("PERFORM_UNTIL", "PERFORM_VARYING", "PERFORM_TIMES"):
                    java_stmt = stmt_trans.translate_statement(s)
                    lines.append(f"        {java_stmt}")
                    lines.append("        if (skipToNextSentence) break;")
                    continue
                
                if stype == "END-PERFORM":
                    lines.append("        }")
                    continue
                    
                java_stmt = stmt_trans.translate_statement(s)
                if java_stmt and not java_stmt.startswith("// Unsupported statement:"):
                    lines.append(f"        {java_stmt}")
            lines.append("    }")
            lines.append("")

        lines.append("    public static void main(String[] args) {")
        lines.append("        try {")
        lines.append(f"            new {class_name}().execute();")
        lines.append("        } catch (StopRunException e) {")
        lines.append("            System.exit(0);")
        lines.append("        }")
        lines.append("    }")
        lines.append("")
        lines.append("    private static String formatSigned(long value, int length, boolean signed) {")
        lines.append("        if (!signed) {")
        lines.append("            return String.format(\"%0\" + length + \"d\", Math.abs(value));")
        lines.append("        }")
        lines.append("        if (value >= 0) {")
        lines.append("            return String.format(\"%0\" + length + \"d\", value);")
        lines.append("        } else {")
        lines.append("            long absVal = Math.abs(value);")
        lines.append("            String absStr = String.format(\"%0\" + length + \"d\", absVal);")
        lines.append("            char lastChar = absStr.charAt(absStr.length() - 1);")
        lines.append("            char signChar;")
        lines.append("            switch (lastChar) {")
        lines.append("                case '0': signChar = 'p'; break;")
        lines.append("                case '1': signChar = 'q'; break;")
        lines.append("                case '2': signChar = 'r'; break;")
        lines.append("                case '3': signChar = 's'; break;")
        lines.append("                case '4': signChar = 't'; break;")
        lines.append("                case '5': signChar = 'u'; break;")
        lines.append("                case '6': signChar = 'v'; break;")
        lines.append("                case '7': signChar = 'w'; break;")
        lines.append("                case '8': signChar = 'x'; break;")
        lines.append("                case '9': signChar = 'y'; break;")
        lines.append("                default: signChar = lastChar;")
        lines.append("            }")
        lines.append("            return absStr.substring(0, absStr.length() - 1) + signChar;")
        lines.append("        }")
        lines.append("    }")
        lines.append("")
        lines.append("    private static BigDecimal parseSigned(String val, int scale) {")
        lines.append("        if (val == null || val.trim().isEmpty()) {")
        lines.append("            return BigDecimal.ZERO;")
        lines.append("        }")
        lines.append("        val = val.trim();")
        lines.append("        char last = val.charAt(val.length() - 1);")
        lines.append("        boolean negative = false;")
        lines.append("        char replacement = last;")
        lines.append("        if (last >= 'p' && last <= 'y') {")
        lines.append("            negative = true;")
        lines.append("            replacement = (char) ('0' + (last - 'p'));")
        lines.append("        }")
        lines.append("        String cleanVal = val.substring(0, val.length() - 1) + replacement;")
        lines.append("        BigDecimal bd = new BigDecimal(cleanVal);")
        lines.append("        if (negative) {")
        lines.append("            bd = bd.negate();")
        lines.append("        }")
        lines.append("        return bd.movePointLeft(scale);")
        lines.append("    }")
        lines.append("")
        lines.append("    private static long parseSignedLong(String val) {")
        lines.append("        if (val == null || val.trim().isEmpty()) {")
        lines.append("            return 0;")
        lines.append("        }")
        lines.append("        val = val.trim();")
        lines.append("        char last = val.charAt(val.length() - 1);")
        lines.append("        boolean negative = false;")
        lines.append("        char replacement = last;")
        lines.append("        if (last >= 'p' && last <= 'y') {")
        lines.append("            negative = true;")
        lines.append("            replacement = (char) ('0' + (last - 'p'));")
        lines.append("        }")
        lines.append("        String cleanVal = val.substring(0, val.length() - 1) + replacement;")
        lines.append("        long l = Long.parseLong(cleanVal);")
        lines.append("        return negative ? -l : l;")
        lines.append("    }")
        lines.append("")
        lines.append("    private static boolean checkSizeError(BigDecimal val, int digits, int scale, boolean signed) {")
        lines.append("        if (val == null) return true;")
        lines.append("        try {")
        lines.append("            BigDecimal limit = BigDecimal.TEN.pow(digits - scale).subtract(BigDecimal.ONE.movePointLeft(scale));")
        lines.append("            BigDecimal minLimit = signed ? limit.negate() : BigDecimal.ZERO;")
        lines.append("            return val.compareTo(limit) > 0 || val.compareTo(minLimit) < 0;")
        lines.append("        } catch (Exception e) {")
        lines.append("            return true;")
        lines.append("        }")
        lines.append("    }")
        lines.append("")
        lines.append("    private static String padString(String val, int length) {")
        lines.append("        if (val == null) val = \"\";")
        lines.append("        String padded = String.format(\"%-\" + length + \"s\", val);")
        lines.append("        if (padded.length() > length) return padded.substring(0, length);")
        lines.append("        return padded;")
        lines.append("    }")
        lines.append("")
        lines.append("}")
        return "\n".join(lines)
