       IDENTIFICATION DIVISION.
       PROGRAM-ID. INVENTORY01.

       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT REPORT-FILE ASSIGN TO "data/out/inventory_report.txt"
               ORGANIZATION IS LINE SEQUENTIAL.

       DATA DIVISION.
       FILE SECTION.
       FD REPORT-FILE.
       01 REPORT-REC PIC X(100).

       WORKING-STORAGE SECTION.
       COPY ITEM-COPY.
       01 WS-EXTENDED       PIC 9(9)V99 VALUE 0.
       01 WS-REORDER        PIC X(10) VALUE SPACES.
       01 WS-LINE           PIC X(100).

       PROCEDURE DIVISION.
           DISPLAY "INVENTORY01 START".
           COMPUTE WS-EXTENDED = ITEM-QTY * ITEM-PRICE.

           IF ITEM-QTY < 10
               MOVE "REORDER" TO WS-REORDER
           ELSE
               MOVE "STOCKED" TO WS-REORDER
           END-IF.

           EVALUATE ITEM-STATUS
               WHEN "ACTIVE"
                   CONTINUE
               WHEN OTHER
                   MOVE "CHECK" TO WS-REORDER
           END-EVALUATE.

           DISPLAY "ITEM=" ITEM-ID.
           DISPLAY "QTY=" ITEM-QTY.
           DISPLAY "PRICE=" ITEM-PRICE.
           DISPLAY "EXTENDED=" WS-EXTENDED.
           DISPLAY "ACTION=" WS-REORDER.

           OPEN OUTPUT REPORT-FILE.
           STRING ITEM-ID DELIMITED BY SIZE
                  " | " DELIMITED BY SIZE
                  ITEM-NAME DELIMITED BY SIZE
                  " | QTY=" DELIMITED BY SIZE
                  ITEM-QTY DELIMITED BY SIZE
                  " | PRICE=" DELIMITED BY SIZE
                  ITEM-PRICE DELIMITED BY SIZE
                  " | TOTAL=" DELIMITED BY SIZE
                  WS-EXTENDED DELIMITED BY SIZE
                  " | " DELIMITED BY SIZE
                  WS-REORDER DELIMITED BY SIZE
                  INTO WS-LINE
           END-STRING.
           WRITE REPORT-REC FROM WS-LINE.
           CLOSE REPORT-FILE.

           DISPLAY "INVENTORY01 END".
           GOBACK.
