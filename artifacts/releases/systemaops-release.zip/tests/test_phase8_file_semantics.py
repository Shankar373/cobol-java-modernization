import sys
import os
import subprocess
import tempfile
import shutil
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from modernize.lexer import CobolLexer
from modernize.parser import CobolParser
from modernize.native_generator import NativeProgramGenerator

def run_cobol_code(program_name: str, code: str, input_files: dict = None) -> tuple:
    filename = f"{program_name}.cob"
    lexer = CobolLexer(filename)
    tokens = lexer.tokenize(code)
    parser = CobolParser(tokens, filename)
    ir = parser.parse()
    
    gen = NativeProgramGenerator(program_name, list(ir.nodes.values()))
    java_source = gen.generate_class_source()
    for line in java_source.splitlines():
        if "Paths.get" in line:
            print("PATH LINE:", line.strip())
    
    temp_dir = tempfile.mkdtemp()
    try:
        pkg_dir = os.path.join(temp_dir, "com", "systema", "modernized", "native_gen")
        os.makedirs(pkg_dir, exist_ok=True)
        
        # Write input files
        if input_files:
            for k, v in input_files.items():
                p = os.path.join(temp_dir, k)
                os.makedirs(os.path.dirname(p), exist_ok=True)
                with open(p, "w", encoding="utf-8") as f:
                    f.write(v)
                    
        # Adjust assignments in generated Java to refer to absolute paths in temp_dir
        adjusted_java_source = java_source
        for assign in gen.file_assigns:
            k = assign.get("physical_path") or assign.get("assign_path")
            if k:
                abs_p = os.path.abspath(os.path.join(temp_dir, k)).replace("\\", "/")
                adjusted_java_source = adjusted_java_source.replace(f'"{k}"', f'"{abs_p}"')
            
        src_file = os.path.join(pkg_dir, f"{program_name.capitalize()}.java")
        with open(src_file, "w", encoding="utf-8") as f:
            f.write(adjusted_java_source)
            
        compile_res = subprocess.run(
            ["javac", src_file],
            capture_output=True,
            text=True
        )
        if compile_res.returncode != 0:
            raise RuntimeError(f"Java compilation failed:\n{compile_res.stderr}\nSource:\n{adjusted_java_source}")
            
        run_res = subprocess.run(
            ["java", "-cp", temp_dir, f"com.systema.modernized.native_gen.{program_name.capitalize()}"],
            capture_output=True,
            text=True
        )
        
        # Read output files
        outputs = {}
        for root, _, files in os.walk(temp_dir):
            for file in files:
                if not file.endswith(".class") and not file.endswith(".java") and file not in (input_files or {}):
                    rel_p = os.path.relpath(os.path.join(root, file), temp_dir).replace("\\", "/")
                    with open(os.path.join(root, file), "r", encoding="utf-8") as f:
                        outputs[rel_p] = f.read()
                        
        return run_res.returncode, run_res.stdout, run_res.stderr, adjusted_java_source, outputs
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

def test_file_control_parsing():
    code = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. FILETEST.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT MY-FILE ASSIGN TO "input.dat"
               ORGANIZATION IS INDEXED
               ACCESS MODE IS RANDOM
               RECORD KEY IS MY-KEY
               FILE STATUS IS MY-STATUS.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 MY-STATUS PIC X(2).
       01 MY-RECORD.
          05 MY-KEY PIC X(5).
          05 MY-DATA PIC X(10).
       PROCEDURE DIVISION.
           GOBACK.
    """
    lexer = CobolLexer("FILETEST.cob")
    tokens = lexer.tokenize(code)
    print("TOKENS:", [(t.type, t.value) for t in tokens])
    parser = CobolParser(tokens, "FILETEST.cob")
    ir = parser.parse()
    
    fc_nodes = [n for n in ir.nodes.values() if n.kind == "FILE_CONTROL"]
    assert len(fc_nodes) == 1
    props = fc_nodes[0].properties
    print("PROPS:", props)
    assert props["file_name"] == "MY-FILE"
    assert props["assign_name"] == 'input.dat'
    assert props["organization"] == "INDEXED"
    assert props["access_mode"] == "RANDOM"
    assert props["record_key"] == "MY-KEY"
    assert props["status_var"] == "MY-STATUS"

def test_invalid_key_parsing():
    code = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. KEYTEST.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT MY-FILE ASSIGN TO "input.dat"
               ORGANIZATION IS INDEXED
               RECORD KEY IS MY-KEY
               FILE STATUS IS MY-STATUS.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 MY-STATUS PIC X(2).
       01 MY-RECORD.
          05 MY-KEY PIC X(5).
          05 MY-DATA PIC X(10).
       PROCEDURE DIVISION.
           READ MY-FILE
               INVALID KEY MOVE "23" TO MY-STATUS
               NOT INVALID KEY MOVE "00" TO MY-STATUS
           END-READ.
           GOBACK.
    """
    lexer = CobolLexer("KEYTEST.cob")
    tokens = lexer.tokenize(code)
    parser = CobolParser(tokens, "KEYTEST.cob")
    ir = parser.parse()
    
    stmt_nodes = [n for n in ir.nodes.values() if n.kind == "STATEMENT" and n.properties.get("statement_type") == "READ"]
    assert len(stmt_nodes) == 1
    props = stmt_nodes[0].properties
    assert len(props["invalid_key_nodes"]) == 1
    assert len(props["not_invalid_key_nodes"]) == 1
    assert props["invalid_key_nodes"][0].properties["statement_type"] == "MOVE"
    assert props["not_invalid_key_nodes"][0].properties["statement_type"] == "MOVE"

def test_sequential_file_operations_success():
    code = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. SEQTEST.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT IN-FILE ASSIGN TO "in.dat"
               ORGANIZATION IS LINE SEQUENTIAL
               FILE STATUS IS WS-STATUS.
           SELECT OUT-FILE ASSIGN TO "out.dat"
               ORGANIZATION IS LINE SEQUENTIAL
               FILE STATUS IS WS-STATUS.
       DATA DIVISION.
       FILE SECTION.
       FD IN-FILE.
       01 IN-REC.
          05 IN-VAL PIC X(5).
       FD OUT-FILE.
       01 OUT-REC.
          05 OUT-VAL PIC X(5).
       WORKING-STORAGE SECTION.
       01 WS-STATUS PIC X(2) VALUE "  ".
       PROCEDURE DIVISION.
           OPEN INPUT IN-FILE.
           DISPLAY "OPEN IN STATUS: " WS-STATUS.
           OPEN OUTPUT OUT-FILE.
           DISPLAY "OPEN OUT STATUS: " WS-STATUS.
           READ IN-FILE.
           DISPLAY "READ STATUS: " WS-STATUS " VAL: " IN-VAL.
           MOVE IN-VAL TO OUT-VAL.
           WRITE OUT-REC.
           DISPLAY "WRITE STATUS: " WS-STATUS.
           READ IN-FILE.
           DISPLAY "READ EOF STATUS: " WS-STATUS.
           CLOSE IN-FILE.
           DISPLAY "CLOSE IN STATUS: " WS-STATUS.
           CLOSE OUT-FILE.
           DISPLAY "CLOSE OUT STATUS: " WS-STATUS.
           GOBACK.
    """
    inputs = {"in.dat": "HELLO\n"}
    ret, stdout, stderr, java_src, outputs = run_cobol_code("SEQTEST", code, inputs)
    print("STDOUT:", stdout)
    print("STDERR:", stderr)
    assert ret == 0
    lines = [l.strip() for l in stdout.strip().splitlines()]
    assert "OPEN IN STATUS:  00" in lines
    assert "OPEN OUT STATUS:  00" in lines
    assert "READ STATUS:  00  VAL:  HELLO" in lines
    assert "WRITE STATUS:  00" in lines
    assert "READ EOF STATUS:  10" in lines
    assert "CLOSE IN STATUS:  00" in lines
    assert "CLOSE OUT STATUS:  00" in lines
    assert outputs.get("out.dat") == "HELLO\n"

def test_open_input_file_not_found():
    code = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. MISSINGTEST.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT IN-FILE ASSIGN TO "missing.dat"
               FILE STATUS IS WS-STATUS.
       DATA DIVISION.
       FILE SECTION.
       FD IN-FILE.
       01 IN-REC PIC X(5).
       WORKING-STORAGE SECTION.
       01 WS-STATUS PIC X(2) VALUE "  ".
       PROCEDURE DIVISION.
           OPEN INPUT IN-FILE.
           DISPLAY "OPEN STATUS: " WS-STATUS.
           GOBACK.
    """
    ret, stdout, stderr, java_src, outputs = run_cobol_code("MISSINGTEST", code)
    assert ret == 0
    lines = [l.strip() for l in stdout.strip().splitlines()]
    assert "OPEN STATUS:  35" in lines

def test_indexed_operations():
    code = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. INDEXTEST.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT IDX-FILE ASSIGN TO "idx.dat"
               ORGANIZATION IS INDEXED
               ACCESS MODE IS RANDOM
               RECORD KEY IS IDX-KEY
               FILE STATUS IS WS-STATUS.
       DATA DIVISION.
       FILE SECTION.
       FD IDX-FILE.
       01 IDX-REC.
          05 IDX-KEY PIC X(5).
          05 IDX-VAL PIC X(5).
       WORKING-STORAGE SECTION.
       01 WS-STATUS PIC X(2) VALUE "  ".
       PROCEDURE DIVISION.
           OPEN OUTPUT IDX-FILE.
           MOVE "K1234" TO IDX-KEY.
           MOVE "VAL01" TO IDX-VAL.
           WRITE IDX-REC
               INVALID KEY DISPLAY "WRITE K1234 INVALID"
               NOT INVALID KEY DISPLAY "WRITE K1234 SUCCESS".
           DISPLAY "WRITE STATUS: " WS-STATUS.
           
           *> Test duplicate write
           WRITE IDX-REC
               INVALID KEY DISPLAY "WRITE DUP INVALID"
               NOT INVALID KEY DISPLAY "WRITE DUP SUCCESS".
           DISPLAY "DUP WRITE STATUS: " WS-STATUS.
           
           CLOSE IDX-FILE.
           
           OPEN INPUT IDX-FILE.
           MOVE "K1234" TO IDX-KEY.
           READ IDX-FILE
               INVALID KEY DISPLAY "READ K1234 INVALID"
               NOT INVALID KEY DISPLAY "READ K1234 SUCCESS: " IDX-VAL.
           DISPLAY "READ STATUS: " WS-STATUS.
           
           *> Test missing key
           MOVE "K9999" TO IDX-KEY.
           READ IDX-FILE
               INVALID KEY DISPLAY "READ K9999 INVALID"
               NOT INVALID KEY DISPLAY "READ K9999 SUCCESS".
           DISPLAY "MISSING READ STATUS: " WS-STATUS.
           
           CLOSE IDX-FILE.
           
           OPEN I-O IDX-FILE.
           MOVE "K1234" TO IDX-KEY.
           MOVE "VAL02" TO IDX-VAL.
           REWRITE IDX-REC
               INVALID KEY DISPLAY "REWRITE INVALID"
               NOT INVALID KEY DISPLAY "REWRITE SUCCESS".
           DISPLAY "REWRITE STATUS: " WS-STATUS.
           
           *> Test missing rewrite
           MOVE "K9999" TO IDX-KEY.
           REWRITE IDX-REC
               INVALID KEY DISPLAY "REWRITE MISSING INVALID"
               NOT INVALID KEY DISPLAY "REWRITE MISSING SUCCESS".
           DISPLAY "REWRITE MISSING STATUS: " WS-STATUS.
           
           CLOSE IDX-FILE.
           GOBACK.
    """
    ret, stdout, stderr, java_src, outputs = run_cobol_code("INDEXTEST", code)
    assert ret == 0
    lines = [l.strip() for l in stdout.strip().splitlines()]
    assert "WRITE K1234 SUCCESS" in lines
    assert "WRITE STATUS:  00" in lines
    assert "WRITE DUP INVALID" in lines
    assert "DUP WRITE STATUS:  22" in lines
    assert "READ K1234 SUCCESS:  VAL01" in lines
    assert "READ STATUS:  00" in lines
    assert "READ K9999 INVALID" in lines
    assert "MISSING READ STATUS:  23" in lines
    assert "REWRITE SUCCESS" in lines
    assert "REWRITE STATUS:  00" in lines
    assert "REWRITE MISSING INVALID" in lines
    assert "REWRITE MISSING STATUS:  23" in lines
    
    # Zero dependencies check
    forbidden = ["jp.osscons", "libcobj", "CobolResolve", "opensourcecobol"]
    for word in forbidden:
        assert word not in java_src
