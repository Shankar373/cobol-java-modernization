import re
from .lexer import CobolToken
from .semantic_ir import SemanticIR, SemanticIRNode

class ParserDiagnostic(Exception):
    def __init__(self, message: str, file: str, line: int, column: int, token_value: str, context: str):
        super().__init__(f"{message} at line {line}, col {column} (token: {token_value})")
        self.message = message
        self.file = file
        self.line = line
        self.column = column
        self.token_value = token_value
        self.context = context

    def to_dict(self) -> dict:
        return {
            "type": "PARSER_SYNTAX_ERROR",
            "message": self.message,
            "source_location": {
                "file": self.file,
                "line": self.line,
                "column": self.column
            },
            "offending_token": self.token_value,
            "context": self.context
        }


def parse_picture_clause(pic_str: str):
    pic = pic_str.upper()
    signed = pic.startswith("S")
    if signed:
        pic = pic[1:]
    
    expanded = []
    i = 0
    while i < len(pic):
        char = pic[i]
        if i + 1 < len(pic) and pic[i+1] == "(":
            end = pic.find(")", i + 1)
            if end != -1:
                try:
                    count = int(pic[i+2:end])
                    expanded.append(char * count)
                except ValueError:
                    expanded.append(char)
                i = end + 1
                continue
        expanded.append(char)
        i += 1
    
    expanded_str = "".join(expanded)
    if "V" in expanded_str:
        parts = expanded_str.split("V")
        digits = parts[0].count("9") + parts[1].count("9")
        scale = parts[1].count("9")
    else:
        digits = expanded_str.count("9")
        scale = 0
    
    return signed, digits, scale


COBOL_KEYWORDS = {
    "IDENTIFICATION", "PROGRAM-ID", "ENVIRONMENT", "CONFIGURATION", "INPUT-OUTPUT", "FILE-CONTROL",
    "SELECT", "ASSIGN", "ORGANIZATION", "INDEXED", "ACCESS", "DYNAMIC", "RECORD", "KEY", "STATUS",
    "DATA", "FILE", "FD", "WORKING-STORAGE", "LINKAGE", "PROCEDURE", "DIVISION", "SECTION",
    "MOVE", "TO", "ADD", "SUBTRACT", "MULTIPLY", "DIVIDE", "COMPUTE", "IF", "ELSE", "PERFORM", "THRU", "UNTIL",
    "DISPLAY", "GOBACK", "EXIT", "INITIALIZE", "READ", "WRITE", "REWRITE", "OPEN", "CLOSE",
    "STOP", "RUN", "COPY", "PIC", "PICTURE", "USAGE", "COMP", "COMP-3", "DISPLAY", "BINARY", "PACKED-DECIMAL",
    "REDEFINES", "OCCURS", "JUSTIFIED", "JUST", "VALUE", "VALUES", "WHEN", "TRUE", "FALSE", "EVALUATE",
    "END-IF", "END-PERFORM", "END-READ", "END-WRITE", "END-EVALUATE", "NOT", "EQUAL", "GREATER", "THAN", "LESS",
    "AND", "OR", "ON", "SIZE", "ERROR", "DECLARATIVES", "END-DECLARATIVES", "RETURN", "VARYING", "CALL", "USING",
    "GO", "CONTINUE", "NEXT", "SENTENCE", "INVALID", "RANDOM", "MODE", "IN", "OVERFLOW",
    "UNSTRING", "INSPECT", "TALLYING", "REPLACING", "CONVERTING", "POINTER", "CHARACTERS", "FIRST", "END-UNSTRING",
    "ALL", "LEADING", "WITH", "FOR"
}


STATEMENT_START_VERBS = {
    "MOVE", "COMPUTE", "ADD", "SUBTRACT", "MULTIPLY", "DIVIDE", "PERFORM", "CALL", "READ", "WRITE", 
    "REWRITE", "OPEN", "CLOSE", "STOP", "GOBACK", "IF", "ELSE", "END-IF", "THEN",
    "EVALUATE", "WHEN", "END-EVALUATE", "STRING", "AT", "NOT", "END-READ",
    "DISPLAY", "INITIALIZE", "EXIT", "END-PERFORM", "GO", "CONTINUE", "NEXT",
    "UNSTRING", "INSPECT", "END-UNSTRING"
}


class CobolParser:
    def __init__(self, tokens: list, file_path: str):
        self.tokens = tokens
        self.file_path = file_path
        self.current = 0
        self.diagnostics = []
        self.ir = SemanticIR()
        self.node_counter = 0
        self.block_stack = []
        self.sentence_ended = False
        self.sentence_id = 0

        # Intercept node addition to record sentence boundaries
        original_add_node = self.ir.add_node
        def custom_add_node(node):
            if node.kind == "STATEMENT" and "sentence_id" not in node.properties:
                node.properties["sentence_id"] = self.sentence_id
            original_add_node(node)
        self.ir.add_node = custom_add_node

    def next_node_id(self) -> str:
        self.node_counter += 1
        return f"node_{self.node_counter:05d}"

    def peek(self, offset: int = 0) -> CobolToken:
        if self.current + offset >= len(self.tokens):
            return CobolToken("EOF", "", self.file_path, 0, 0, 0, 0)
        return self.tokens[self.current + offset]

    def is_at_end(self) -> bool:
        return self.current >= len(self.tokens) or self.peek().type == "EOF"

    def check(self, type_: str, value: str = None) -> bool:
        if self.is_at_end():
            return False
        tok = self.peek()
        if tok.type != type_:
            return False
        if value is not None and tok.value.upper() != value.upper():
            return False
        return True

    def match(self, type_: str, value: str = None) -> bool:
        if self.check(type_, value):
            self.current += 1
            return True
        return False

    def match_statement_period(self) -> bool:
        if self.match("PUNCTUATION", "."):
            self.sentence_ended = True
            return True
        return False

    def close_implicit_scopes(self, token):
        while self.block_stack:
            kind = self.block_stack.pop()
            end_type = f"END-{kind}"
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={"statement_type": end_type},
                source_file=self.file_path,
                source_line=token.line,
                source_column=token.column,
                start_offset=token.start_offset,
                end_offset=token.end_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

    def consume(self, type_: str, value: str = None, message: str = "Expected token") -> CobolToken:
        if self.check(type_, value):
            tok = self.peek()
            self.current += 1
            return tok
        
        offending = self.peek()
        diag = ParserDiagnostic(
            message=message,
            file=self.file_path,
            line=offending.line,
            column=offending.column,
            token_value=offending.value,
            context=f"Parsing around token {offending.value}"
        )
        self.diagnostics.append(diag)
        raise diag

    def consume_val(self, message: str = "Expected identifier or literal") -> CobolToken:
        tok = self.peek()
        if tok.type in ("IDENTIFIER", "LITERAL_STRING", "LITERAL_NUMBER", "KEYWORD"):
            self.current += 1
            return tok
        
        diag = ParserDiagnostic(
            message=message,
            file=self.file_path,
            line=tok.line,
            column=tok.column,
            token_value=tok.value,
            context=f"Parsing value around {tok.value}"
        )
        self.diagnostics.append(diag)
        raise diag

    def consume_subscripted_identifier(self, message: str = "Expected identifier") -> str:
        tok = self.consume("IDENTIFIER", None, message)
        val = tok.value
        if self.match("PUNCTUATION", "("):
            parts = [val, "("]
            depth = 1
            while depth > 0 and not self.is_at_end():
                t = self.peek()
                self.current += 1
                parts.append(t.value)
                if t.type == "PUNCTUATION" and t.value == "(":
                    depth += 1
                elif t.type == "PUNCTUATION" and t.value == ")":
                    depth -= 1
            val = "".join(parts)
        return val

    def consume_val_or_subscript(self, message: str = "Expected identifier or literal"):
        class SubscriptValue:
            def __init__(self, value: str):
                self.value = value
        
        tok = self.peek()
        if tok.type in ("IDENTIFIER", "KEYWORD"):
            val = self.consume_subscripted_identifier()
            return SubscriptValue(val)
        else:
            return self.consume_val(message)


    def parse(self) -> SemanticIR:
        while not self.is_at_end():
            try:
                if self.check("KEYWORD", "IDENTIFICATION") or self.check("KEYWORD", "ID"):
                    self.parse_identification_division()
                elif self.check("KEYWORD", "ENVIRONMENT"):
                    self.parse_environment_division()
                elif self.check("KEYWORD", "DATA"):
                    self.parse_data_division()
                elif self.check("KEYWORD", "PROCEDURE"):
                    self.parse_procedure_division()
                else:
                    self.current += 1
            except ParserDiagnostic:
                # Recover to next division
                while not self.is_at_end() and not self.check("KEYWORD", "ENVIRONMENT") and not self.check("KEYWORD", "DATA") and not self.check("KEYWORD", "PROCEDURE"):
                    self.current += 1
        return self.ir

    def parse_identification_division(self):
        start_tok = self.peek()
        if self.match("KEYWORD", "IDENTIFICATION") or self.match("KEYWORD", "ID"):
            self.consume("KEYWORD", "DIVISION", "Expected DIVISION keyword")
            self.consume("PUNCTUATION", ".", "Expected period after DIVISION")
        
        node = SemanticIRNode(
            node_id=self.next_node_id(),
            kind="DIVISION",
            properties={"name": "IDENTIFICATION"},
            source_file=self.file_path,
            source_line=start_tok.line,
            source_column=start_tok.column,
            start_offset=start_tok.start_offset,
            end_offset=self.peek().start_offset,
            status="PARSED"
        )
        self.ir.add_node(node)

        # Parse PROGRAM-ID
        if self.match("KEYWORD", "PROGRAM-ID"):
            self.consume("PUNCTUATION", ".", "Expected period after PROGRAM-ID")
            prog_name_tok = self.consume("IDENTIFIER", None, "Expected program name identifier")
            self.consume("PUNCTUATION", ".", "Expected period after program name")
            
            p_node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="PROGRAM",
                properties={"name": prog_name_tok.value},
                source_file=self.file_path,
                source_line=prog_name_tok.line,
                source_column=prog_name_tok.column,
                start_offset=prog_name_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(p_node)

    def parse_environment_division(self):
        start_tok = self.peek()
        self.consume("KEYWORD", "ENVIRONMENT", "Expected ENVIRONMENT")
        self.consume("KEYWORD", "DIVISION", "Expected DIVISION")
        self.consume("PUNCTUATION", ".", "Expected period")

        node = SemanticIRNode(
            node_id=self.next_node_id(),
            kind="DIVISION",
            properties={"name": "ENVIRONMENT"},
            source_file=self.file_path,
            source_line=start_tok.line,
            source_column=start_tok.column,
            start_offset=start_tok.start_offset,
            end_offset=self.peek().start_offset,
            status="PARSED"
        )
        self.ir.add_node(node)

        while not self.is_at_end() and not self.check("KEYWORD", "DATA") and not self.check("KEYWORD", "PROCEDURE"):
            if self.match("KEYWORD", "CONFIGURATION") or self.match("KEYWORD", "INPUT-OUTPUT"):
                name = self.peek(-1).value
                self.consume("KEYWORD", "SECTION", "Expected SECTION")
                self.consume("PUNCTUATION", ".", "Expected period")
                
                sec_node = SemanticIRNode(
                    node_id=self.next_node_id(),
                    kind="SECTION",
                    properties={"name": name},
                    source_file=self.file_path,
                    source_line=start_tok.line,
                    source_column=start_tok.column,
                    start_offset=start_tok.start_offset,
                    end_offset=self.peek().start_offset,
                    status="PARSED"
                )
                self.ir.add_node(sec_node)
                if name == "INPUT-OUTPUT":
                    self.parse_input_output_section()
            else:
                self.current += 1

    def parse_input_output_section(self):
        while not self.is_at_end() and not self.check("KEYWORD", "DATA") and not self.check("KEYWORD", "PROCEDURE") and not self.check("KEYWORD", "CONFIGURATION"):
            if self.match("KEYWORD", "FILE-CONTROL"):
                self.consume("PUNCTUATION", ".", "Expected period after FILE-CONTROL")
                self.parse_file_control()
            else:
                self.current += 1

    def parse_file_control(self):
        while not self.is_at_end() and self.check("KEYWORD", "SELECT"):
            self.parse_select_statement()

    def match_is_keyword(self) -> bool:
        if self.check("KEYWORD", "IS"):
            self.current += 1
            return True
        if self.check("IDENTIFIER") and self.peek().value.upper() == "IS":
            self.current += 1
            return True
        return False

    def parse_select_statement(self):
        start_tok = self.peek()
        self.consume("KEYWORD", "SELECT")
        file_name = self.consume("IDENTIFIER", None, "Expected file-name after SELECT").value
        
        assign_name = None
        status_var = None
        org_type = "SEQUENTIAL"
        access_mode = "SEQUENTIAL"
        record_key = None
        
        while not self.is_at_end() and not self.check("PUNCTUATION", "."):
            if self.match("KEYWORD", "ASSIGN"):
                self.match("KEYWORD", "TO")
                if self.check("IDENTIFIER") or self.check("LITERAL_STRING"):
                    assign_name = self.peek().value
                    self.current += 1
                else:
                    self.consume("IDENTIFIER", None, "Expected physical assignment after ASSIGN TO")
            elif self.match("KEYWORD", "ORGANIZATION"):
                self.match_is_keyword()
                if self.match("KEYWORD", "INDEXED"):
                    org_type = "INDEXED"
                elif self.match("KEYWORD", "LINE"):
                    self.consume("KEYWORD", "SEQUENTIAL")
                    org_type = "LINE SEQUENTIAL"
                elif self.match("KEYWORD", "SEQUENTIAL"):
                    org_type = "SEQUENTIAL"
            elif self.match("KEYWORD", "ACCESS"):
                if self.check("KEYWORD", "MODE") or (self.check("IDENTIFIER") and self.peek().value.upper() == "MODE"):
                    self.current += 1
                self.match_is_keyword()
                if self.match("KEYWORD", "SEQUENTIAL"):
                    access_mode = "SEQUENTIAL"
                elif self.match("KEYWORD", "RANDOM"):
                    access_mode = "RANDOM"
                elif self.match("KEYWORD", "DYNAMIC"):
                    access_mode = "DYNAMIC"
            elif self.match("KEYWORD", "RECORD"):
                self.consume("KEYWORD", "KEY")
                self.match_is_keyword()
                record_key = self.consume("IDENTIFIER", None, "Expected record key identifier").value
            elif self.match("KEYWORD", "FILE"):
                self.consume("KEYWORD", "STATUS")
                self.match_is_keyword()
                status_var = self.consume("IDENTIFIER", None, "Expected file status variable").value
            else:
                self.current += 1
                
        self.consume("PUNCTUATION", ".", "Expected period after SELECT statement")
        
        node = SemanticIRNode(
            node_id=self.next_node_id(),
            kind="FILE_CONTROL",
            properties={
                "file_name": file_name,
                "assign_name": assign_name,
                "organization": org_type,
                "access_mode": access_mode,
                "record_key": record_key,
                "status_var": status_var
            },
            source_file=self.file_path,
            source_line=start_tok.line,
            source_column=start_tok.column,
            start_offset=start_tok.start_offset,
            end_offset=self.peek().start_offset,
            status="PARSED"
        )
        self.ir.add_node(node)

    def parse_data_division(self):
        start_tok = self.peek()
        self.consume("KEYWORD", "DATA", "Expected DATA")
        self.consume("KEYWORD", "DIVISION", "Expected DIVISION")
        self.consume("PUNCTUATION", ".", "Expected period")

        node = SemanticIRNode(
            node_id=self.next_node_id(),
            kind="DIVISION",
            properties={"name": "DATA"},
            source_file=self.file_path,
            source_line=start_tok.line,
            source_column=start_tok.column,
            start_offset=start_tok.start_offset,
            end_offset=self.peek().start_offset,
            status="PARSED"
        )
        self.ir.add_node(node)

        while not self.is_at_end() and not self.check("KEYWORD", "PROCEDURE"):
            if self.check("KEYWORD", "FILE") or self.check("KEYWORD", "WORKING-STORAGE") or self.check("KEYWORD", "LINKAGE"):
                sec_tok = self.peek()
                self.current += 1
                sec_name = sec_tok.value
                self.consume("KEYWORD", "SECTION", "Expected SECTION")
                self.consume("PUNCTUATION", ".", "Expected period")
                
                sec_node = SemanticIRNode(
                    node_id=self.next_node_id(),
                    kind="SECTION",
                    properties={"name": sec_name},
                    source_file=self.file_path,
                    source_line=sec_tok.line,
                    source_column=sec_tok.column,
                    start_offset=sec_tok.start_offset,
                    end_offset=self.peek().start_offset,
                    status="PARSED"
                )
                self.ir.add_node(sec_node)
                self.parse_data_items()
            else:
                self.current += 1

    def parse_data_items(self):
        while not self.is_at_end() and not self.check("KEYWORD", "PROCEDURE") and not self.check("KEYWORD", "FILE") and not self.check("KEYWORD", "WORKING-STORAGE") and not self.check("KEYWORD", "LINKAGE"):
            if self.check("LITERAL_NUMBER"):
                lvl_tok = self.peek()
                lvl = int(lvl_tok.value)
                
                # Accept any valid COBOL level number (01-49, 66, 77, 88)
                if lvl < 1 or (lvl > 49 and lvl not in (66, 77, 88)):
                    self.current += 1
                    continue
                
                self.current += 1
                
                name_tok = self.peek()
                if self.check("IDENTIFIER") or self.check("KEYWORD"):
                    self.current += 1
                    name = name_tok.value
                else:
                    name = "FILLER"
                
                props = {
                    "name": name,
                    "level": lvl,
                    "picture": None,
                    "usage": None,
                    "value": None,
                    "redefines": None,
                    "occurs": None,
                    "occurs_min": None,
                    "occurs_max": None,
                    "depending_on": None,
                    "signed": False,
                    "digits": 0,
                    "scale": 0,
                    "is_group": True,
                    "condition_values": []
                }
                
                while not self.is_at_end() and not self.check("PUNCTUATION", "."):
                    if self.match("KEYWORD", "REDEFINES"):
                        ref_tok = self.consume("IDENTIFIER", None, "Expected identifier after REDEFINES")
                        props["redefines"] = ref_tok.value
                    
                    elif self.match("KEYWORD", "PIC") or self.match("KEYWORD", "PICTURE"):
                        self.match("KEYWORD", "IS")
                        
                        pic_parts = []
                        while not self.is_at_end() and not self.check("KEYWORD") and not self.check("PUNCTUATION", "."):
                            pic_parts.append(self.peek().value)
                            self.current += 1
                        
                        pic_str = "".join(pic_parts)
                        props["picture"] = pic_str
                        props["is_group"] = False
                        
                        signed, digits, scale = parse_picture_clause(pic_str)
                        props["signed"] = signed
                        props["digits"] = digits
                        props["scale"] = scale
                        
                    elif self.match("KEYWORD", "USAGE"):
                        self.match("KEYWORD", "IS")
                        usage_tok = self.peek()
                        self.current += 1
                        props["usage"] = usage_tok.value.upper()
                        
                    elif self.match("KEYWORD", "COMP") or self.match("KEYWORD", "COMP-3") or self.match("KEYWORD", "BINARY") or self.match("KEYWORD", "DISPLAY"):
                        props["usage"] = self.peek(-1).value.upper()
                        
                    elif self.match("KEYWORD", "VALUE") or self.match("KEYWORD", "VALUES"):
                        self.match("KEYWORD", "IS")
                        val_tok = self.peek()
                        self.current += 1
                        props["value"] = val_tok.value
                        
                        if lvl == 88:
                            props["condition_values"].append(val_tok.value)
                            
                    elif self.match("KEYWORD", "OCCURS"):
                        first_tok = self.consume("LITERAL_NUMBER", None, "Expected count after OCCURS")
                        first_val = int(first_tok.value)
                        
                        min_val = first_val
                        max_val = first_val
                        
                        if self.match("KEYWORD", "TO"):
                            max_tok = self.consume("LITERAL_NUMBER", None, "Expected maximum count after TO")
                            max_val = int(max_tok.value)
                            
                        self.match("KEYWORD", "TIMES")
                        
                        props["occurs"] = max_val
                        props["occurs_min"] = min_val
                        props["occurs_max"] = max_val
                        
                        if self.match("KEYWORD", "DEPENDING"):
                            self.match("KEYWORD", "ON")
                            dep_tok = self.consume("IDENTIFIER", None, "Expected identifier after DEPENDING ON")
                            props["depending_on"] = dep_tok.value
                    else:
                        self.current += 1
                
                self.consume("PUNCTUATION", ".", "Expected period after data item definition")
                
                node = SemanticIRNode(
                    node_id=self.next_node_id(),
                    kind="DATA_ITEM",
                    properties=props,
                    source_file=self.file_path,
                    source_line=lvl_tok.line,
                    source_column=lvl_tok.column,
                    start_offset=lvl_tok.start_offset,
                    end_offset=self.peek().start_offset,
                    status="PARSED"
                )
                self.ir.add_node(node)
            else:
                self.current += 1

    def parse_procedure_division(self):
        start_tok = self.peek()
        self.consume("KEYWORD", "PROCEDURE", "Expected PROCEDURE")
        self.consume("KEYWORD", "DIVISION", "Expected DIVISION")
        using_args = []
        if self.match("KEYWORD", "USING"):
            while not self.is_at_end() and not self.check("PUNCTUATION", "."):
                tok = self.peek()
                if tok.type in ("IDENTIFIER", "KEYWORD"):
                    using_args.append(tok.value.upper())
                self.current += 1
        
        self.consume("PUNCTUATION", ".", "Expected period")

        node = SemanticIRNode(
            node_id=self.next_node_id(),
            kind="DIVISION",
            properties={"name": "PROCEDURE", "using_args": using_args},
            source_file=self.file_path,
            source_line=start_tok.line,
            source_column=start_tok.column,
            start_offset=start_tok.start_offset,
            end_offset=self.peek().start_offset,
            status="PARSED"
        )
        self.ir.add_node(node)

        while not self.is_at_end():
            is_header = False
            is_section = False
            name_tok = self.peek()
            
            if self.check("IDENTIFIER"):
                if self.peek(1).type == "PUNCTUATION" and self.peek(1).value == ".":
                    is_header = True
                    is_section = False
                elif self.peek(1).type == "KEYWORD" and self.peek(1).value.upper() == "SECTION" and self.peek(2).type == "PUNCTUATION" and self.peek(2).value == ".":
                    is_header = True
                    is_section = True
                    
            if is_header:
                self.close_implicit_scopes(name_tok)
                self.current += 1 # Consume name_tok
                if is_section:
                    self.current += 2 # Consume SECTION and "."
                    kind = "SECTION"
                else:
                    self.current += 1 # Consume "."
                    kind = "PARAGRAPH"
                
                p_node = SemanticIRNode(
                    node_id=self.next_node_id(),
                    kind=kind,
                    properties={"name": name_tok.value},
                    source_file=self.file_path,
                    source_line=name_tok.line,
                    source_column=name_tok.column,
                    start_offset=name_tok.start_offset,
                    end_offset=self.peek().start_offset,
                    status="PARSED"
                )
                self.ir.add_node(p_node)
            else:
                self.parse_statement()

    def parse_nested_statement(self):
        before_keys = list(self.ir.nodes.keys())
        self._parse_statement_internal()
        after_keys = list(self.ir.nodes.keys())
        new_keys = [k for k in after_keys if k not in before_keys]
        if new_keys:
            main_node = self.ir.nodes[new_keys[0]]
            for k in new_keys:
                del self.ir.nodes[k]
            return main_node
        return None

    def parse_nested_statements_block(self, end_keywords, end_verbs=None):
        statements = []
        while not self.is_at_end() and not self.sentence_ended:
            peek_tok = self.peek()
            if peek_tok.type == "KEYWORD" and peek_tok.value.upper() in end_keywords:
                break
            if end_verbs and peek_tok.type == "KEYWORD" and peek_tok.value.upper() in end_verbs:
                break
            if peek_tok.type == "PUNCTUATION" and peek_tok.value == ".":
                break
            stmt = self.parse_nested_statement()
            if stmt:
                statements.append(stmt)
                if self.sentence_ended:
                    break
            else:
                self.current += 1
        return statements

    def parse_statement(self):
        try:
            self.sentence_ended = False
            self._parse_statement_internal()
            if self.sentence_ended:
                self.close_implicit_scopes(self.peek(-1))
                self.sentence_ended = False
                self.sentence_id += 1
        except ParserDiagnostic:
            while not self.is_at_end() and not self.check("PUNCTUATION", ".") and not self.check("KEYWORD", "MOVE") and not self.check("KEYWORD", "IF") and not self.check("KEYWORD", "PERFORM"):
                self.current += 1
            if self.match("PUNCTUATION", "."):
                self.close_implicit_scopes(self.peek(-1))
                self.sentence_id += 1

    def _parse_statement_internal(self):
        start_tok = self.peek()
        
        if self.match("KEYWORD", "MOVE"):
            src_tok = self.consume_val_or_subscript("Expected source identifier or literal in MOVE")
            self.consume("KEYWORD", "TO", "Expected TO keyword")
            # Collect all targets (MOVE X TO A B C)
            targets = []
            while self.check("IDENTIFIER"):
                targets.append(self.consume_subscripted_identifier())
            if not targets:
                tgt_val = self.consume_subscripted_identifier("Expected target identifier")
                targets = [tgt_val]
            self.match_statement_period()
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": "MOVE",
                    "source": src_tok.value,
                    "targets": targets
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)
            
        elif self.match("KEYWORD", "COMPUTE"):
            tgt_val = self.consume_subscripted_identifier("Expected target identifier")
            self.consume("PUNCTUATION", "=", "Expected '=' in COMPUTE")
            
            expr_parts = []
            while not self.is_at_end() and not self.check("PUNCTUATION", ".") and not self.check("KEYWORD"):
                tok = self.peek()
                if tok.type in ("IDENTIFIER", "LITERAL_NUMBER", "PUNCTUATION"):
                    expr_parts.append(tok.value)
                    self.current += 1
                else:
                    break
            
            on_size_error_nodes = []
            not_on_size_error_nodes = []
            
            while not self.is_at_end() and not self.check("PUNCTUATION", ".") and not self.sentence_ended:
                if self.match("KEYWORD", "ON") or self.check("KEYWORD", "SIZE"):
                    if not self.match("KEYWORD", "SIZE"):
                        self.match("KEYWORD", "SIZE")
                    self.consume("KEYWORD", "ERROR", "Expected ERROR after SIZE")
                    on_size_error_nodes = self.parse_nested_statements_block(
                        ["NOT", "END-COMPUTE"]
                    )
                elif self.match("KEYWORD", "NOT"):
                    self.consume("KEYWORD", "ON", "Expected ON after NOT")
                    self.consume("KEYWORD", "SIZE", "Expected SIZE after ON")
                    self.consume("KEYWORD", "ERROR", "Expected ERROR after SIZE")
                    not_on_size_error_nodes = self.parse_nested_statements_block(
                        ["END-COMPUTE"]
                    )
                elif self.match("KEYWORD", "END-COMPUTE"):
                    break
                else:
                    break

            self.match_statement_period()
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": "COMPUTE",
                    "target": tgt_val,
                    "expression": " ".join(expr_parts),
                    "on_size_error_nodes": on_size_error_nodes,
                    "not_on_size_error_nodes": not_on_size_error_nodes
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        elif self.match("KEYWORD", "ADD") or self.match("KEYWORD", "SUBTRACT") or self.match("KEYWORD", "MULTIPLY") or self.match("KEYWORD", "DIVIDE"):
            op = self.peek(-1).value.upper()
            val_tok = self.consume_val_or_subscript("Expected value to perform calculation")
            
            mid_kw = "TO"
            if op == "SUBTRACT":
                mid_kw = "FROM"
            elif op == "MULTIPLY":
                mid_kw = "BY"
            elif op == "DIVIDE":
                if self.check("KEYWORD", "INTO"):
                    mid_kw = "INTO"
                else:
                    mid_kw = "BY"
                
            self.consume("KEYWORD", mid_kw, f"Expected {mid_kw} keyword")
            tgt_val = self.consume_subscripted_identifier("Expected target/value identifier")
            
            giving_tgt = None
            if self.match("KEYWORD", "GIVING"):
                giving_tgt = self.consume_subscripted_identifier("Expected target identifier after GIVING")
                
            on_size_error_nodes = []
            not_on_size_error_nodes = []
            end_verb = f"END-{op}"
            
            while not self.is_at_end() and not self.check("PUNCTUATION", ".") and not self.sentence_ended:
                if self.match("KEYWORD", "ON") or self.check("KEYWORD", "SIZE"):
                    if not self.match("KEYWORD", "SIZE"):
                        self.match("KEYWORD", "SIZE")
                    self.consume("KEYWORD", "ERROR", "Expected ERROR after SIZE")
                    on_size_error_nodes = self.parse_nested_statements_block(
                        ["NOT", end_verb]
                    )
                elif self.match("KEYWORD", "NOT"):
                    self.consume("KEYWORD", "ON", "Expected ON after NOT")
                    self.consume("KEYWORD", "SIZE", "Expected SIZE after ON")
                    self.consume("KEYWORD", "ERROR", "Expected ERROR after SIZE")
                    not_on_size_error_nodes = self.parse_nested_statements_block(
                        [end_verb]
                    )
                elif self.match("KEYWORD", end_verb):
                    break
                else:
                    break
                    
            self.match_statement_period()
            
            props = {
                "statement_type": op,
                "value": val_tok.value,
                "target": giving_tgt if giving_tgt else tgt_val,
                "on_size_error_nodes": on_size_error_nodes,
                "not_on_size_error_nodes": not_on_size_error_nodes
            }
            if giving_tgt:
                props["operand2"] = tgt_val
                
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties=props,
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        elif self.match("KEYWORD", "IF"):
            cond_parts = []
            while not self.is_at_end() and not self.check("PUNCTUATION", "."):
                tok = self.peek()
                if tok.type == "KEYWORD" and tok.value.upper() in STATEMENT_START_VERBS:
                    break
                self.current += 1
                if tok.type == "LITERAL_STRING":
                    cond_parts.append(f'"{tok.value}"')
                else:
                    cond_parts.append(tok.value)
            
            self.match("KEYWORD", "THEN")
            self.block_stack.append("IF")
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": "IF",
                    "condition": " ".join(cond_parts)
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        elif self.match("KEYWORD", "ELSE"):
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={"statement_type": "ELSE"},
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        elif self.match("KEYWORD", "PERFORM"):
            is_times = False
            times_idx = -1
            for offset in range(1, 6):
                if self.peek(offset).value.upper() == "TIMES":
                    is_times = True
                    times_idx = offset
                    break
            
            if is_times:
                if times_idx == 1:
                    count_tok = self.consume_val_or_subscript("Expected repeat count in PERFORM TIMES")
                    if self.check("KEYWORD", "TIMES") or self.check("IDENTIFIER", "TIMES"):
                        self.current += 1
                    else:
                        self.consume("KEYWORD", "TIMES", "Expected TIMES keyword")
                    props = {
                        "statement_type": "PERFORM_TIMES",
                        "count": count_tok.value
                    }
                    self.block_stack.append("PERFORM")
                else:
                    target = self.consume("IDENTIFIER", None, "Expected paragraph/section target name").value
                    thru = None
                    if self.match("KEYWORD", "THRU"):
                        thru = self.consume("IDENTIFIER", None, "Expected THRU target name").value
                    count_tok = self.consume_val_or_subscript("Expected repeat count in PERFORM TIMES")
                    if self.check("KEYWORD", "TIMES") or self.check("IDENTIFIER", "TIMES"):
                        self.current += 1
                    else:
                        self.consume("KEYWORD", "TIMES", "Expected TIMES keyword")
                    props = {
                        "statement_type": "PERFORM_TIMES_OUT",
                        "target": target,
                        "thru": thru,
                        "count": count_tok.value
                    }
            elif self.match("KEYWORD", "VARYING"):
                # PERFORM VARYING idx FROM start BY step UNTIL cond
                idx_val = self.consume_subscripted_identifier("Expected index variable after VARYING")
                self.consume("KEYWORD", "FROM", "Expected FROM in PERFORM VARYING")
                from_tok = self.consume_val_or_subscript("Expected FROM value")
                self.consume("KEYWORD", "BY", "Expected BY in PERFORM VARYING")
                by_tok = self.consume_val_or_subscript("Expected BY value")
                self.consume("KEYWORD", "UNTIL", "Expected UNTIL in PERFORM VARYING")
                cond_parts = []
                while not self.is_at_end() and not self.check("PUNCTUATION", "."):
                    tok = self.peek()
                    if tok.type == "KEYWORD" and tok.value.upper() in STATEMENT_START_VERBS:
                        break
                    self.current += 1
                    if tok.type == "LITERAL_STRING":
                        cond_parts.append(f'"{tok.value}"')
                    else:
                        cond_parts.append(tok.value)
                props = {
                    "statement_type": "PERFORM_VARYING",
                    "index": idx_val,
                    "from_value": from_tok.value,
                    "by_value": by_tok.value,
                    "condition": " ".join(cond_parts)
                }
                self.block_stack.append("PERFORM")
            elif self.match("KEYWORD", "UNTIL"):
                cond_parts = []
                while not self.is_at_end() and not self.check("PUNCTUATION", "."):
                    tok = self.peek()
                    if tok.type == "KEYWORD" and tok.value.upper() in STATEMENT_START_VERBS:
                        break
                    self.current += 1
                    if tok.type == "LITERAL_STRING":
                        cond_parts.append(f'"{tok.value}"')
                    else:
                        cond_parts.append(tok.value)
                props = {"statement_type": "PERFORM_UNTIL", "condition": " ".join(cond_parts)}
                self.block_stack.append("PERFORM")
            else:
                tgt_tok = self.consume("IDENTIFIER", None, "Expected paragraph name after PERFORM")
                props = {"statement_type": "PERFORM", "target": tgt_tok.value}
                if self.match("KEYWORD", "THRU"):
                    thru_tok = self.consume("IDENTIFIER", None, "Expected THRU paragraph name")
                    props["thru"] = thru_tok.value
            
            self.match_statement_period()
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties=props,
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        elif self.match("KEYWORD", "DISPLAY"):
            operands = []
            while not self.is_at_end() and not self.check("PUNCTUATION", "."):
                tok = self.peek()
                if tok.type == "KEYWORD" and tok.value.upper() in STATEMENT_START_VERBS:
                    break
                if tok.type == "LITERAL_STRING":
                    self.current += 1
                    operands.append({"type": "literal", "value": tok.value})
                elif tok.type == "LITERAL_NUMBER":
                    self.current += 1
                    operands.append({"type": "literal", "value": tok.value})
                elif tok.type in ("IDENTIFIER", "KEYWORD"):
                    val = self.consume_subscripted_identifier()
                    operands.append({"type": "variable", "value": val})
                else:
                    self.current += 1
            
            self.match_statement_period()
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": "DISPLAY",
                    "operands": operands
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        elif self.match("KEYWORD", "STRING"):
            parts = []
            while not self.is_at_end() and not self.check("KEYWORD", "INTO"):
                val_tok = self.consume_val("Expected value in STRING")
                self.consume("KEYWORD", "DELIMITED", "Expected DELIMITED")
                self.match("KEYWORD", "BY")
                delim_tok = self.consume_val("Expected delimiter in STRING")
                parts.append({
                    "value": val_tok.value,
                    "delimited_by": delim_tok.value
                })
            
            self.consume("KEYWORD", "INTO", "Expected INTO keyword in STRING")
            tgt_tok = self.consume("IDENTIFIER", None, "Expected target identifier in STRING")
            self.match("PUNCTUATION", ".")
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": "STRING",
                    "parts": parts,
                    "target": tgt_tok.value
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        elif self.match("KEYWORD", "UNSTRING"):
            source_tok = self.consume_val("Expected source identifier or literal in UNSTRING")
            
            delimited_by = None
            if self.match("KEYWORD", "DELIMITED"):
                self.match("KEYWORD", "BY")
                delim_tok = self.consume_val("Expected delimiter in UNSTRING")
                delimited_by = delim_tok.value
                
            self.consume("KEYWORD", "INTO", "Expected INTO keyword in UNSTRING")
            targets = []
            while not self.is_at_end() and not self.check("PUNCTUATION", "."):
                peek_tok = self.peek()
                if peek_tok.type == "KEYWORD" and peek_tok.value.upper() in ("WITH", "POINTER", "TALLYING", "ON", "NOT", "END-UNSTRING"):
                    break
                if peek_tok.type == "KEYWORD" and peek_tok.value.upper() in STATEMENT_START_VERBS:
                    break
                tgt_tok = self.consume("IDENTIFIER", None, "Expected target identifier in UNSTRING")
                targets.append(tgt_tok.value)
                
            pointer_var = None
            tally_var = None
            on_overflow_nodes = []
            not_on_overflow_nodes = []
            
            while not self.is_at_end() and not self.check("PUNCTUATION", ".") and not self.sentence_ended:
                if self.match("KEYWORD", "WITH") or self.check("KEYWORD", "POINTER"):
                    if not self.match("KEYWORD", "POINTER"):
                        self.match("KEYWORD", "POINTER")
                    pointer_tok = self.consume("IDENTIFIER", None, "Expected POINTER variable")
                    pointer_var = pointer_tok.value
                elif self.match("KEYWORD", "TALLYING"):
                    if self.match("KEYWORD", "IN"):
                        pass
                    tally_tok = self.consume("IDENTIFIER", None, "Expected TALLYING variable")
                    tally_var = tally_tok.value
                elif self.match("KEYWORD", "ON") or self.check("KEYWORD", "OVERFLOW"):
                    if self.peek(-1).value.upper() == "ON" and self.match("KEYWORD", "OVERFLOW"):
                        pass
                    elif self.match("KEYWORD", "OVERFLOW"):
                        pass
                    on_overflow_nodes = self.parse_nested_statements_block(
                        ["NOT", "END-UNSTRING"]
                    )
                elif self.match("KEYWORD", "NOT"):
                    self.consume("KEYWORD", "ON", "Expected ON after NOT")
                    self.consume("KEYWORD", "OVERFLOW", "Expected OVERFLOW after ON")
                    not_on_overflow_nodes = self.parse_nested_statements_block(
                        ["END-UNSTRING"]
                    )
                elif self.match("KEYWORD", "END-UNSTRING"):
                    break
                else:
                    break
                    
            self.match_statement_period()
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": "UNSTRING",
                    "source": source_tok.value,
                    "delimited_by": delimited_by,
                    "targets": targets,
                    "pointer": pointer_var,
                    "tallying": tally_var,
                    "on_overflow_nodes": on_overflow_nodes,
                    "not_on_overflow_nodes": not_on_overflow_nodes
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        elif self.match("KEYWORD", "INSPECT"):
            target_tok = self.consume("IDENTIFIER", None, "Expected target identifier in INSPECT")
            
            inspect_type = None
            tally_var = None
            tally_type = None
            tally_search = None
            replacements = []
            converting_from = None
            converting_to = None
            
            if self.match("KEYWORD", "TALLYING"):
                inspect_type = "TALLYING"
                tally_var = self.consume("IDENTIFIER", None, "Expected tally variable").value
                self.consume("KEYWORD", "FOR", "Expected FOR in INSPECT TALLYING")
                
                if self.match("KEYWORD", "CHARACTERS"):
                    tally_type = "CHARACTERS"
                elif self.match("KEYWORD", "ALL"):
                    tally_type = "ALL"
                    search_tok = self.consume_val("Expected search value after ALL")
                    tally_search = search_tok.value
                elif self.match("KEYWORD", "LEADING"):
                    tally_type = "LEADING"
                    search_tok = self.consume_val("Expected search value after LEADING")
                    tally_search = search_tok.value
                else:
                    raise ParserDiagnostic("Expected CHARACTERS, ALL, or LEADING in INSPECT TALLYING", self.file_path, self.peek().line, self.peek().column, self.peek().value, "")
                    
            elif self.match("KEYWORD", "REPLACING"):
                inspect_type = "REPLACING"
                while not self.is_at_end() and not self.check("PUNCTUATION", "."):
                    peek_tok = self.peek()
                    if peek_tok.type != "KEYWORD" or peek_tok.value.upper() not in ("CHARACTERS", "ALL", "LEADING", "FIRST"):
                        break
                        
                    rep_type = None
                    search_val = None
                    
                    if self.match("KEYWORD", "CHARACTERS"):
                        rep_type = "CHARACTERS"
                        self.consume("KEYWORD", "BY", "Expected BY after CHARACTERS")
                        rep_val = self.consume_val("Expected replacement value").value
                    elif self.match("KEYWORD", "ALL"):
                        rep_type = "ALL"
                        search_val = self.consume_val("Expected search value").value
                        self.consume("KEYWORD", "BY", "Expected BY after search value")
                        rep_val = self.consume_val("Expected replacement value").value
                    elif self.match("KEYWORD", "LEADING"):
                        rep_type = "LEADING"
                        search_val = self.consume_val("Expected search value").value
                        self.consume("KEYWORD", "BY", "Expected BY after search value")
                        rep_val = self.consume_val("Expected replacement value").value
                    elif self.match("KEYWORD", "FIRST"):
                        rep_type = "FIRST"
                        search_val = self.consume_val("Expected search value").value
                        self.consume("KEYWORD", "BY", "Expected BY after search value")
                        rep_val = self.consume_val("Expected replacement value").value
                    else:
                        break
                    replacements.append({
                        "type": rep_type,
                        "search": search_val,
                        "replace": rep_val
                    })
                    
            elif self.match("KEYWORD", "CONVERTING"):
                inspect_type = "CONVERTING"
                from_tok = self.consume_val("Expected source characters in CONVERTING")
                self.consume("KEYWORD", "TO", "Expected TO in CONVERTING")
                to_tok = self.consume_val("Expected destination characters in CONVERTING")
                converting_from = from_tok.value
                converting_to = to_tok.value
            else:
                raise ParserDiagnostic("Expected TALLYING, REPLACING, or CONVERTING in INSPECT", self.file_path, self.peek().line, self.peek().column, self.peek().value, "")
                
            self.match_statement_period()
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": "INSPECT",
                    "target": target_tok.value,
                    "inspect_type": inspect_type,
                    "tally_var": tally_var,
                    "tally_type": tally_type,
                    "tally_search": tally_search,
                    "replacements": replacements,
                    "converting_from": converting_from,
                    "converting_to": converting_to
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        elif self.match("KEYWORD", "CALL"):
            tgt_tok = self.consume_val("Expected subprogram target name")
            
            args = []
            if self.match("KEYWORD", "USING"):
                while not self.is_at_end() and not self.check("PUNCTUATION", ".") and not self.check("KEYWORD"):
                    tok = self.consume_val("Expected USING argument name")
                    args.append(tok.value)
            
            self.match("PUNCTUATION", ".")
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": "CALL",
                    "target": tgt_tok.value,
                    "arguments": args
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        elif self.match("KEYWORD", "READ") or self.match("KEYWORD", "WRITE") or self.match("KEYWORD", "REWRITE"):
            op = self.peek(-1).value.upper()
            file_tok = self.consume("IDENTIFIER", None, f"Expected file identifier after {op}")
            
            from_source = None
            into_target = None
            at_end_nodes = []
            not_at_end_nodes = []
            invalid_key_nodes = []
            not_invalid_key_nodes = []
            
            if op in ("WRITE", "REWRITE") and self.match("KEYWORD", "FROM"):
                from_tok = self.consume_val("Expected source identifier/literal after FROM")
                from_source = from_tok.value
            elif op == "READ":
                if self.match("KEYWORD", "INTO"):
                    into_tok = self.consume("IDENTIFIER", None, "Expected target identifier after INTO")
                    into_target = into_tok.value
                    
            # Parse clauses for all READ/WRITE/REWRITE
            in_at_end = False
            in_not_at_end = False
            in_invalid_key = False
            in_not_invalid_key = False
            
            while not self.is_at_end():
                if self.check("KEYWORD", "AT") and not self.is_at_end():
                    self.current += 1
                    if self.match("KEYWORD", "END"):
                        in_at_end = True
                        in_not_at_end = False
                        in_invalid_key = False
                        in_not_invalid_key = False
                        continue
                    self.current -= 1
                    break
                elif self.check("KEYWORD", "INVALID") and not self.is_at_end():
                    self.current += 1
                    if self.match("KEYWORD", "KEY"):
                        in_invalid_key = True
                        in_not_invalid_key = False
                        in_at_end = False
                        in_not_at_end = False
                        continue
                    self.current -= 1
                    break
                elif self.check("KEYWORD", "NOT") and not self.is_at_end():
                    self.current += 1
                    if self.check("KEYWORD", "AT"):
                        self.current += 1
                        if self.match("KEYWORD", "END"):
                            in_not_at_end = True
                            in_at_end = False
                            in_invalid_key = False
                            in_not_invalid_key = False
                            continue
                        self.current -= 1
                    elif self.check("KEYWORD", "INVALID"):
                        self.current += 1
                        if self.match("KEYWORD", "KEY"):
                            in_not_invalid_key = True
                            in_invalid_key = False
                            in_at_end = False
                            in_not_at_end = False
                            continue
                        self.current -= 1
                    self.current -= 1
                    break
                elif self.check("KEYWORD", f"END-{op}"):
                    self.current += 1
                    break
                elif in_at_end or in_not_at_end or in_invalid_key or in_not_invalid_key:
                    tok = self.peek()
                    if tok.type == "KEYWORD" and tok.value.upper() in STATEMENT_START_VERBS and tok.value.upper() not in ("AT", "NOT", f"END-{op}", "INVALID"):
                        stmt_node = None
                        if self.match("KEYWORD", "MOVE"):
                            src_tok = self.consume_val("Expected source in MOVE")
                            self.consume("KEYWORD", "TO", "Expected TO")
                            in_targets = []
                            while self.check("IDENTIFIER"):
                                in_targets.append(self.peek().value)
                                self.current += 1
                            if not in_targets:
                                in_t = self.consume("IDENTIFIER", None, "Expected target")
                                in_targets = [in_t.value]
                            stmt_node = SemanticIRNode(
                                node_id=self.next_node_id(),
                                kind="STATEMENT",
                                properties={"statement_type": "MOVE", "source": src_tok.value, "targets": in_targets},
                                source_file=self.file_path,
                                source_line=tok.line,
                                source_column=tok.column,
                                start_offset=tok.start_offset,
                                end_offset=self.peek().start_offset,
                                status="PARSED"
                            )
                        elif self.match("KEYWORD", "WRITE") or self.match("KEYWORD", "REWRITE"):
                            w_op = self.peek(-1).value.upper()
                            file_tok2 = self.consume("IDENTIFIER", None, f"Expected file/record after {w_op}")
                            from_src = None
                            if self.match("KEYWORD", "FROM"):
                                from_tok2 = self.consume_val("Expected source after FROM")
                                from_src = from_tok2.value
                            stmt_node = SemanticIRNode(
                                node_id=self.next_node_id(),
                                kind="STATEMENT",
                                properties={"statement_type": w_op, "target": file_tok2.value, "from_source": from_src, "into_target": None, "at_end_nodes": [], "not_at_end_nodes": []},
                                source_file=self.file_path,
                                source_line=tok.line,
                                source_column=tok.column,
                                start_offset=tok.start_offset,
                                end_offset=self.peek().start_offset,
                                status="PARSED"
                            )
                        elif self.match("KEYWORD", "PERFORM"):
                            tgt_tok = self.consume("IDENTIFIER", None, "Expected paragraph name after PERFORM")
                            props = {"statement_type": "PERFORM", "target": tgt_tok.value}
                            if self.match("KEYWORD", "THRU"):
                                thru_tok = self.consume("IDENTIFIER", None, "Expected THRU paragraph name")
                                props["thru"] = thru_tok.value
                            stmt_node = SemanticIRNode(
                                node_id=self.next_node_id(),
                                kind="STATEMENT",
                                properties=props,
                                source_file=self.file_path,
                                source_line=tok.line,
                                source_column=tok.column,
                                start_offset=tok.start_offset,
                                end_offset=self.peek().start_offset,
                                status="PARSED"
                            )
                        elif self.match("KEYWORD", "DISPLAY"):
                            operands = []
                            while not self.is_at_end() and not self.check("PUNCTUATION", "."):
                                tok2 = self.peek()
                                if tok2.type == "KEYWORD" and (tok2.value.upper() in STATEMENT_START_VERBS or tok2.value.upper() in ("AT", "NOT", "INVALID", f"END-{op}")):
                                    break
                                val_tok = self.consume_val("Expected display operand")
                                operands.append({
                                    "type": "literal" if val_tok.type == "LITERAL_STRING" else "variable",
                                    "value": val_tok.value
                                })
                            stmt_node = SemanticIRNode(
                                node_id=self.next_node_id(),
                                kind="STATEMENT",
                                properties={"statement_type": "DISPLAY", "operands": operands},
                                source_file=self.file_path,
                                source_line=tok.line,
                                source_column=tok.column,
                                start_offset=tok.start_offset,
                                end_offset=self.peek().start_offset,
                                status="PARSED"
                            )
                        elif self.match("KEYWORD", "STOP"):
                            self.consume("KEYWORD", "RUN")
                            stmt_node = SemanticIRNode(
                                node_id=self.next_node_id(),
                                kind="STATEMENT",
                                properties={"statement_type": "STOP RUN"},
                                source_file=self.file_path,
                                source_line=tok.line,
                                source_column=tok.column,
                                start_offset=tok.start_offset,
                                end_offset=self.peek().start_offset,
                                status="PARSED"
                            )
                        elif self.match("KEYWORD", "GOBACK"):
                            stmt_node = SemanticIRNode(
                                node_id=self.next_node_id(),
                                kind="STATEMENT",
                                properties={"statement_type": "GOBACK"},
                                source_file=self.file_path,
                                source_line=tok.line,
                                source_column=tok.column,
                                start_offset=tok.start_offset,
                                end_offset=self.peek().start_offset,
                                status="PARSED"
                            )
                        elif self.match("KEYWORD", "CONTINUE"):
                            stmt_node = SemanticIRNode(
                                node_id=self.next_node_id(),
                                kind="STATEMENT",
                                properties={"statement_type": "CONTINUE"},
                                source_file=self.file_path,
                                source_line=tok.line,
                                source_column=tok.column,
                                start_offset=tok.start_offset,
                                end_offset=self.peek().start_offset,
                                status="PARSED"
                            )
                        
                        if stmt_node:
                            if in_at_end:
                                at_end_nodes.append(stmt_node)
                            elif in_not_at_end:
                                not_at_end_nodes.append(stmt_node)
                            elif in_invalid_key:
                                invalid_key_nodes.append(stmt_node)
                            elif in_not_invalid_key:
                                not_invalid_key_nodes.append(stmt_node)
                        else:
                            break
                    else:
                        break
                else:
                    break
            
            self.match_statement_period()
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": op,
                    "target": file_tok.value,
                    "from_source": from_source,
                    "into_target": into_target,
                    "at_end_nodes": at_end_nodes,
                    "not_at_end_nodes": not_at_end_nodes,
                    "invalid_key_nodes": invalid_key_nodes,
                    "not_invalid_key_nodes": not_invalid_key_nodes
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        elif self.match("KEYWORD", "OPEN") or self.match("KEYWORD", "CLOSE"):
            op = self.peek(-1).value.upper()
            targets = []
            if op == "OPEN":
                # Support: OPEN INPUT F1 F2 OUTPUT F3 F4
                while not self.is_at_end() and not self.check("PUNCTUATION", ".") and not (self.check("KEYWORD") and self.peek().value.upper() in STATEMENT_START_VERBS):
                    if self.check("KEYWORD") and self.peek().value.upper() in ("INPUT", "OUTPUT", "I-O", "EXTEND"):
                        mode_kw = self.peek().value.upper()
                        self.current += 1
                        # We can optionally keep the mode keyword in the targets list or treat it as mode
                        targets.append(mode_kw)
                    file_tok = self.consume("IDENTIFIER", None, "Expected file identifier after OPEN mode")
                    targets.append(file_tok.value)
            else:
                while not self.is_at_end() and not self.check("PUNCTUATION", ".") and not (self.check("KEYWORD") and self.peek().value.upper() in STATEMENT_START_VERBS):
                    file_tok = self.consume("IDENTIFIER", None, "Expected file identifier after CLOSE")
                    targets.append(file_tok.value)
                
            self.match_statement_period()
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": op,
                    "targets": targets
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        elif self.match("KEYWORD", "EVALUATE"):
            subject_tok = self.consume_val("Expected subject after EVALUATE")
            self.match_statement_period()
            self.block_stack.append("EVALUATE")
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": "EVALUATE",
                    "subject": subject_tok.value
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        elif self.match("KEYWORD", "WHEN"):
            cond_parts = []
            while not self.is_at_end() and not self.check("PUNCTUATION", "."):
                tok = self.peek()
                if tok.type == "KEYWORD" and tok.value.upper() in STATEMENT_START_VERBS:
                    break
                self.current += 1
                if tok.type == "LITERAL_STRING":
                    cond_parts.append(f'"{tok.value}"')
                else:
                    cond_parts.append(tok.value)
            
            cond_str = " ".join(cond_parts)
            self.match_statement_period()
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": "WHEN",
                    "condition": cond_str
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        elif self.match("KEYWORD", "STOP") or self.match("KEYWORD", "GOBACK"):
            val = self.peek(-1).value.upper()
            if val == "STOP":
                self.consume("KEYWORD", "RUN", "Expected RUN after STOP")
                val = "STOP RUN"
            self.match_statement_period()
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": val
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)
        elif self.match("KEYWORD", "GO"):
            self.consume("KEYWORD", "TO", "Expected TO after GO")
            tgt_tok = self.consume("IDENTIFIER", None, "Expected paragraph/section name after GO TO")
            self.match_statement_period()
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": "GO TO",
                    "target": tgt_tok.value
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)
        elif self.match("KEYWORD", "NEXT"):
            if self.match("KEYWORD", "SENTENCE") or self.match("IDENTIFIER", "SENTENCE"):
                self.match_statement_period()
                node = SemanticIRNode(
                    node_id=self.next_node_id(),
                    kind="STATEMENT",
                    properties={
                        "statement_type": "NEXT SENTENCE"
                    },
                    source_file=self.file_path,
                    source_line=start_tok.line,
                    source_column=start_tok.column,
                    start_offset=start_tok.start_offset,
                    end_offset=self.peek().start_offset,
                    status="PARSED"
                )
                self.ir.add_node(node)

        elif self.match("KEYWORD", "CONTINUE"):
            self.match_statement_period()
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": "CONTINUE"
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        elif self.match("KEYWORD", "EXIT"):
            exit_type = "EXIT"
            if self.match("KEYWORD", "PERFORM") or self.match("IDENTIFIER", "PERFORM"):
                exit_type = "EXIT PERFORM"
            elif self.match("KEYWORD", "PARAGRAPH") or self.match("IDENTIFIER", "PARAGRAPH"):
                exit_type = "EXIT PARAGRAPH"
            elif self.match("KEYWORD", "SECTION") or self.match("IDENTIFIER", "SECTION"):
                exit_type = "EXIT SECTION"
            
            self.match_statement_period()
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": exit_type
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        elif self.match("KEYWORD", "END-IF") or self.match("KEYWORD", "END-PERFORM") or self.match("KEYWORD", "END-READ") or self.match("KEYWORD", "END-WRITE") or self.match("KEYWORD", "END-EVALUATE"):
            val = self.peek(-1).value.upper()
            block_type = val[4:]  # IF, PERFORM, EVALUATE, READ, WRITE
            if self.block_stack and self.block_stack[-1] == block_type:
                self.block_stack.pop()
            self.match_statement_period()
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": val
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="PARSED"
            )
            self.ir.add_node(node)

        else:
            tok = self.peek()
            self.current += 1
            
            # Skip until period or statement boundary to prevent cascade UNKNOWNs
            while not self.is_at_end() and not self.check("PUNCTUATION", "."):
                peek_tok = self.peek()
                if peek_tok.type == "KEYWORD" and peek_tok.value.upper() in STATEMENT_START_VERBS:
                    break
                self.current += 1
            
            self.match_statement_period()
            
            node = SemanticIRNode(
                node_id=self.next_node_id(),
                kind="STATEMENT",
                properties={
                    "statement_type": "UNKNOWN",
                    "offending_token": tok.value
                },
                source_file=self.file_path,
                source_line=start_tok.line,
                source_column=start_tok.column,
                start_offset=start_tok.start_offset,
                end_offset=self.peek().start_offset,
                status="UNSUPPORTED"
            )
            self.ir.add_node(node)
