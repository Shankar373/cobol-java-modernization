       01 ITEM-RECORD.
           05 ITEM-ID          PIC 9(6) VALUE 200001.
           05 ITEM-NAME        PIC X(20) VALUE "WIDGET-A".
           05 ITEM-QTY         PIC 9(5) VALUE 12.
           05 ITEM-PRICE       PIC 9(5)V99 VALUE 25.50.
           05 ITEM-STATUS      PIC X(10) VALUE "ACTIVE".
