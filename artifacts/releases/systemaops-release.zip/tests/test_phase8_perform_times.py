import sys
import os
import subprocess
import tempfile
import shutil
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from modernize.lexer import CobolLexer
from modernize.parser import CobolParser
from modernize.native_generator import NativeProgramGenerator

def run_cobol_code(program_name: str, code: str) -> tuple:
    filename = f"{program_name}.cob"
    lexer = CobolLexer(filename)
    tokens = lexer.tokenize(code)
    parser = CobolParser(tokens, filename)
    ir = parser.parse()
    
    gen = NativeProgramGenerator(program_name, list(ir.nodes.values()))
    java_source = gen.generate_class_source()
    
    temp_dir = tempfile.mkdtemp()
    try:
        pkg_dir = os.path.join(temp_dir, "com", "systema", "modernized", "native_gen")
        os.makedirs(pkg_dir, exist_ok=True)
        
        src_file = os.path.join(pkg_dir, f"{program_name.capitalize()}.java")
        with open(src_file, "w", encoding="utf-8") as f:
            f.write(java_source)
            
        compile_res = subprocess.run(
            ["javac", src_file],
            capture_output=True,
            text=True
        )
        if compile_res.returncode != 0:
            raise Exception(f"Java compilation failed:\n{compile_res.stderr}\nSource:\n{java_source}")
            
        run_res = subprocess.run(
            ["java", "-cp", temp_dir, f"com.systema.modernized.native_gen.{program_name.capitalize()}"],
            capture_output=True,
            text=True
        )
        return run_res.returncode, run_res.stdout.strip().splitlines()
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

def test_perform_times_zero():
    code = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. PERFTIMES0.
        PROCEDURE DIVISION.
        MAIN-PARA.
            PERFORM 0 TIMES
                DISPLAY "LOOPED"
            END-PERFORM.
            DISPLAY "DONE".
            STOP RUN.
    """
    code_val, output = run_cobol_code("PERFTIMES0", code)
    assert code_val == 0
    assert output == ["DONE"]

def test_perform_times_one():
    code = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. PERFTIMES1.
        PROCEDURE DIVISION.
        MAIN-PARA.
            PERFORM 1 TIMES
                DISPLAY "ONCE"
            END-PERFORM.
            STOP RUN.
    """
    code_val, output = run_cobol_code("PERFTIMES1", code)
    assert code_val == 0
    assert output == ["ONCE"]

def test_perform_times_multiple():
    code = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. PERFTIMESM.
        PROCEDURE DIVISION.
        MAIN-PARA.
            PERFORM 3 TIMES
                DISPLAY "HELLO"
            END-PERFORM.
            STOP RUN.
    """
    code_val, output = run_cobol_code("PERFTIMESM", code)
    assert code_val == 0
    assert output == ["HELLO", "HELLO", "HELLO"]

def test_perform_times_nested():
    code = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. PERFTIMESN.
        PROCEDURE DIVISION.
        MAIN-PARA.
            PERFORM 2 TIMES
                PERFORM 3 TIMES
                    DISPLAY "NEST"
                END-PERFORM
            END-PERFORM.
            STOP RUN.
    """
    code_val, output = run_cobol_code("PERFTIMESN", code)
    assert code_val == 0
    assert len(output) == 6
    assert output == ["NEST"] * 6

def test_perform_times_exit_perform():
    code = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. PERFTIMESEX.
        PROCEDURE DIVISION.
        MAIN-PARA.
            PERFORM 5 TIMES
                DISPLAY "LOOP"
                EXIT PERFORM
            END-PERFORM.
            STOP RUN.
    """
    code_val, output = run_cobol_code("PERFTIMESEX", code)
    assert code_val == 0
    assert output == ["LOOP"]

def test_perform_times_conditional():
    code = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. PERFTIMESCOND.
        DATA DIVISION.
        WORKING-STORAGE SECTION.
        01  WS-VAL  PIC 9 VALUE 1.
        PROCEDURE DIVISION.
        MAIN-PARA.
            PERFORM 3 TIMES
                IF WS-VAL = 1
                    DISPLAY "RUN"
                END-IF
            END-PERFORM.
            STOP RUN.
    """
    code_val, output = run_cobol_code("PERFTIMESCOND", code)
    assert code_val == 0
    assert output == ["RUN", "RUN", "RUN"]

def test_perform_times_out_of_line():
    code = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. PERFTIMESOUT.
        PROCEDURE DIVISION.
        MAIN-PARA.
            PERFORM SUB-PARA 3 TIMES.
            STOP RUN.
        SUB-PARA.
            DISPLAY "SUB".
    """
    code_val, output = run_cobol_code("PERFTIMESOUT", code)
    assert code_val == 0
    assert output == ["SUB", "SUB", "SUB"]
