import os
import re
import shutil

def to_java_class(name: str) -> str:
    if not name:
        return ""
    # Remove extension and clean up
    base = os.path.splitext(name)[0]
    cleaned = re.sub(r'[^a-zA-Z0-9]', '', base)
    return cleaned.capitalize()

def to_java_var(name: str) -> str:
    if not name:
        return ""
    cleaned = re.sub(r'[^a-zA-Z0-9]', '', name)
    if not cleaned:
        return "var"
    return cleaned[0].lower() + cleaned[1:]

class EnterpriseApplicationGenerator:
    def __init__(self, repo_path: str, model: dict, native_class_name: str, has_db_evidence: bool = False, has_rest_evidence: bool = False):
        self.repo_path = os.path.abspath(repo_path) if repo_path else ""
        self.model = model
        self.native_class_name = native_class_name
        self.has_db_evidence = has_db_evidence
        self.has_rest_evidence = has_rest_evidence

    def generate_project(self, dest_dir: str):
        shutil.rmtree(dest_dir, ignore_errors=True)
        
        src_main = os.path.join(dest_dir, "src", "main")
        java_base = os.path.join(src_main, "java", "com", "systema", "modernized")
        resources_dir = os.path.join(src_main, "resources")
        
        os.makedirs(java_base, exist_ok=True)
        os.makedirs(os.path.join(java_base, "domain"), exist_ok=True)
        os.makedirs(os.path.join(java_base, "repository"), exist_ok=True)
        os.makedirs(os.path.join(java_base, "service"), exist_ok=True)
        os.makedirs(os.path.join(java_base, "batch"), exist_ok=True)
        os.makedirs(os.path.join(java_base, "controller"), exist_ok=True)
        os.makedirs(resources_dir, exist_ok=True)

        parsed_models = self.model.get("parsed_models", {})
        
        # 1. JPA Repository / Entities (evidence-driven)
        is_jpa_applicable = self.has_db_evidence
        for mname, fields in parsed_models.items():
            self._write_jpa_entity(java_base, mname, fields, is_jpa=is_jpa_applicable)
            if is_jpa_applicable:
                self._write_jpa_repository(java_base, mname)

        # 2. REST Controller (evidence-driven)
        if self.has_rest_evidence:
            self._write_rest_controller(java_base)

        # 3. Spring Batch (evidence-driven)
        has_batch = self._check_batch_evidence()
        if has_batch:
            self._write_spring_batch_config(java_base)

        # 4. Project Metadata
        self._write_pom_xml(dest_dir, is_jpa_applicable)
        self._write_properties(resources_dir, is_jpa_applicable)
        self._write_main_application(java_base)
        self._write_dockerfile(dest_dir)

    def _check_batch_evidence(self) -> bool:
        # If there are file assignments or file operations, batch is applicable
        file_assigns = self.model.get("file_assigns") or {}
        file_ops = self.model.get("file_ops") or {}
        return len(file_assigns) > 0 or len(file_ops) > 0

    def _write_jpa_entity(self, java_base: str, mname: str, fields: list, is_jpa: bool):
        cname = to_java_class(mname)
        lines = []
        lines.append("package com.systema.modernized.domain;")
        lines.append("")
        if is_jpa:
            lines.append("import jakarta.persistence.*;")
            lines.append("import java.math.BigDecimal;")
            lines.append("")
            lines.append("@Entity")
            lines.append(f"@Table(name = \"{mname.lower()}\")")
        else:
            lines.append("import java.math.BigDecimal;")
            lines.append("")
            
        lines.append(f"public class {cname} {{")
        lines.append("")
        
        # Identity field for JPA
        if is_jpa:
            lines.append("    @Id")
            lines.append("    @GeneratedValue(strategy = GenerationType.IDENTITY)")
            lines.append("    private Long internalJpaId;")
            lines.append("")
            
        for f in fields:
            camel = f.get("camel_name", "")
            jtype = f.get("type", "String")
            if not camel:
                continue
            lines.append(f"    private {jtype} {camel};")
            
        lines.append("")
        
        # Getters and setters
        if is_jpa:
            lines.append("    public Long getInternalJpaId() { return internalJpaId; }")
            lines.append("    public void setInternalJpaId(Long id) { this.internalJpaId = id; }")
            lines.append("")
            
        for f in fields:
            camel = f.get("camel_name", "")
            jtype = f.get("type", "String")
            if not camel:
                continue
            cap = camel[0].upper() + camel[1:]
            lines.append(f"    public {jtype} get{cap}() {{ return {camel}; }}")
            lines.append(f"    public void set{cap}({jtype} val) {{ this.{camel} = val; }}")
            lines.append("")
            
        lines.append("}")
        
        path = os.path.join(java_base, "domain", f"{cname}.java")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def _write_jpa_repository(self, java_base: str, mname: str):
        cname = to_java_class(mname)
        lines = []
        lines.append("package com.systema.modernized.repository;")
        lines.append("")
        lines.append(f"import com.systema.modernized.domain.{cname};")
        lines.append("import org.springframework.data.jpa.repository.JpaRepository;")
        lines.append("import org.springframework.stereotype.Repository;")
        lines.append("")
        lines.append("@Repository")
        lines.append(f"public interface {cname}Repository extends JpaRepository<{cname}, Long> {{")
        lines.append("}")
        
        path = os.path.join(java_base, "repository", f"{cname}Repository.java")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def _write_rest_controller(self, java_base: str):
        lines = []
        lines.append("package com.systema.modernized.controller;")
        lines.append("")
        lines.append("import org.springframework.web.bind.annotation.*;")
        lines.append("import org.springframework.http.ResponseEntity;")
        lines.append("")
        lines.append("@RestController")
        lines.append("@RequestMapping(\"/api\")")
        lines.append("public class ModernizedRestController {")
        lines.append("")
        lines.append("    @GetMapping(\"/status\")")
        lines.append("    public ResponseEntity<String> getStatus() {")
        lines.append("        return ResponseEntity.ok(\"Modernized service running successfully\");")
        lines.append("    }")
        lines.append("}")
        
        path = os.path.join(java_base, "controller", "ModernizedRestController.java")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def _write_spring_batch_config(self, java_base: str):
        lines = []
        lines.append("package com.systema.modernized.batch;")
        lines.append("")
        lines.append("import org.springframework.batch.core.Job;")
        lines.append("import org.springframework.batch.core.Step;")
        lines.append("import org.springframework.batch.core.job.builder.JobBuilder;")
        lines.append("import org.springframework.batch.core.repository.JobRepository;")
        lines.append("import org.springframework.batch.core.step.builder.StepBuilder;")
        lines.append("import org.springframework.context.annotation.Bean;")
        lines.append("import org.springframework.context.annotation.Configuration;")
        lines.append("import org.springframework.transaction.PlatformTransactionManager;")
        lines.append("")
        lines.append("@Configuration")
        lines.append("public class SpringBatchConfig {")
        lines.append("")
        lines.append("    @Bean")
        lines.append("    public Job modernizedJob(JobRepository jobRepository, Step step1) {")
        lines.append("        return new JobBuilder(\"modernizedJob\", jobRepository)")
        lines.append("                .start(step1)")
        lines.append("                .build();")
        lines.append("    }")
        lines.append("")
        lines.append("    @Bean")
        lines.append("    public Step step1(JobRepository jobRepository, PlatformTransactionManager transactionManager) {")
        lines.append(f"        String entryClass = \"{to_java_class(self.native_class_name)}\";")
        lines.append("        return new StepBuilder(\"step1\", jobRepository)")
        lines.append("                .tasklet((contribution, chunkContext) -> {")
        lines.append("                    try {")
        lines.append(f"                        new com.systema.modernized.native_gen.{to_java_class(self.native_class_name)}().execute();")
        lines.append(f"                    }} catch (com.systema.modernized.native_gen.{to_java_class(self.native_class_name)}.StopRunException e) {{")
        lines.append("                        // Clean exit via STOP RUN")
        lines.append("                    } catch (Exception e) {")
        lines.append("                        throw new RuntimeException(e);")
        lines.append("                    }")
        lines.append("                    return org.springframework.batch.repeat.RepeatStatus.FINISHED;")
        lines.append("                }, transactionManager)")
        lines.append("                .build();")
        lines.append("    }")
        lines.append("}")
        
        path = os.path.join(java_base, "batch", "SpringBatchConfig.java")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def _write_pom_xml(self, dest_dir: str, is_jpa: bool):
        lines = []
        lines.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
        lines.append("<project xmlns=\"http://maven.apache.org/POM/4.0.0\"")
        lines.append("         xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"")
        lines.append("         xsi:schemaLocation=\"http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd\">")
        lines.append("    <modelVersion>4.0.0</modelVersion>")
        lines.append("    <parent>")
        lines.append("        <groupId>org.springframework.boot</groupId>")
        lines.append("        <artifactId>spring-boot-starter-parent</artifactId>")
        lines.append("        <version>3.2.2</version>")
        lines.append("        <relativePath/>")
        lines.append("    </parent>")
        lines.append("    <groupId>com.systema</groupId>")
        lines.append("    <artifactId>modernized</artifactId>")
        lines.append("    <version>1.0.0</version>")
        lines.append("    <name>modernized</name>")
        lines.append("    <description>Enterprise Modernized Spring Boot App</description>")
        lines.append("    <properties>")
        lines.append("        <java.version>17</java.version>")
        lines.append("    </properties>")
        lines.append("    <dependencies>")
        
        lines.append("        <dependency>")
        lines.append("            <groupId>org.springframework.boot</groupId>")
        lines.append("            <artifactId>spring-boot-starter-web</artifactId>")
        lines.append("        </dependency>")
            
        lines.append("        <dependency>")
        lines.append("            <groupId>org.springframework.boot</groupId>")
        lines.append("            <artifactId>spring-boot-starter-data-jpa</artifactId>")
        lines.append("        </dependency>")
        lines.append("        <dependency>")
        lines.append("            <groupId>com.h2database</groupId>")
        lines.append("            <artifactId>h2</artifactId>")
        lines.append("            <scope>runtime</scope>")
        lines.append("        </dependency>")
            
        if self._check_batch_evidence():
            lines.append("        <dependency>")
            lines.append("            <groupId>org.springframework.boot</groupId>")
            lines.append("            <artifactId>spring-boot-starter-batch</artifactId>")
            lines.append("        </dependency>")
            
        lines.append("        <dependency>")
        lines.append("            <groupId>org.springframework.boot</groupId>")
        lines.append("            <artifactId>spring-boot-starter-test</artifactId>")
        lines.append("            <scope>test</scope>")
        lines.append("        </dependency>")
        lines.append("    </dependencies>")
        lines.append("    <build>")
        lines.append("        <plugins>")
        lines.append("            <plugin>")
        lines.append("                <groupId>org.springframework.boot</groupId>")
        lines.append("                <artifactId>spring-boot-maven-plugin</artifactId>")
        lines.append("            </plugin>")
        lines.append("        </plugins>")
        lines.append("    </build>")
        lines.append("</project>")
        
        path = os.path.join(dest_dir, "pom.xml")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def _write_properties(self, resources_dir: str, is_jpa: bool):
        lines = []
        lines.append("spring.application.name=modernized")
        
        # Always configure datasource so that Spring Boot/Batch/JPA has a valid database definition
        lines.append("spring.datasource.url=jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE")
        lines.append("spring.datasource.driverClassName=org.h2.Driver")
        lines.append("spring.datasource.username=sa")
        lines.append("spring.datasource.password=")
        
        if is_jpa:
            lines.append("spring.jpa.database-platform=org.hibernate.dialect.H2Dialect")
            lines.append("spring.hibernate.ddl-auto=update")
            
        if self._check_batch_evidence():
            lines.append("spring.batch.job.enabled=true")
            lines.append("spring.batch.jdbc.initialize-schema=always")
            
        path = os.path.join(resources_dir, "application.properties")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def _write_main_application(self, java_base: str):
        lines = []
        lines.append("package com.systema.modernized;")
        lines.append("")
        lines.append("import org.springframework.boot.SpringApplication;")
        lines.append("import org.springframework.boot.autoconfigure.SpringBootApplication;")
        lines.append("")
        lines.append("@SpringBootApplication")
        lines.append("public class ModernizedApplication {")
        lines.append("    public static void main(String[] args) {")
        lines.append("        SpringApplication.run(ModernizedApplication.class, args);")
        lines.append("    }")
        lines.append("}")
        
        path = os.path.join(java_base, "ModernizedApplication.java")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def _write_dockerfile(self, dest_dir: str):
        lines = []
        lines.append("FROM openjdk:17-jdk-alpine")
        lines.append("VOLUME /tmp")
        lines.append("COPY target/modernized-1.0.0.jar app.jar")
        lines.append("ENTRYPOINT [\"java\",\"-jar\",\"/app.jar\"]")
        
        path = os.path.join(dest_dir, "Dockerfile")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def analyze_topology(self) -> dict:
        """
        Analyse the discovered file-flow topology.
        Returns a dict with:
          - inputs: list of logical input file names
          - outputs: list of logical output file names
          - programs: list of discovered program IDs
          - flow_type: SINGLE_IO | MULTI_INPUT | MULTI_OUTPUT | MULTI_INDEPENDENT | COMPOSITE
          - gap: True if topology cannot be safely represented in generated Spring artifacts
          - gap_reason: MULTI_FILE_ARCHITECTURAL_GAP message or None
        """
        file_assigns = self.model.get("file_assigns") or {}
        file_ops = self.model.get("file_ops") or {}

        # Classify files by I/O mode
        inputs = [k for k, v in file_ops.items() if v in ("INPUT", "I-O")]
        outputs = [k for k, v in file_ops.items() if v in ("OUTPUT", "EXTEND", "I-O")]
        # Fall back to file_assigns keys if file_ops not available
        if not inputs and not outputs:
            inputs = list(file_assigns.keys())
            outputs = []

        programs = self.model.get("programs") or []

        # Determine flow type
        if len(inputs) <= 1 and len(outputs) <= 1:
            flow_type = "SINGLE_IO"
        elif len(inputs) > 1 and len(outputs) <= 1:
            flow_type = "MULTI_INPUT"
        elif len(inputs) <= 1 and len(outputs) > 1:
            flow_type = "MULTI_OUTPUT"
        elif len(programs) > 1 and (len(inputs) > 1 or len(outputs) > 1):
            flow_type = "COMPOSITE"
        else:
            flow_type = "MULTI_INDEPENDENT"

        # Gap check: if there are multiple independent programs each with their own
        # files but the model doesn't declare how they interconnect, flag a gap.
        gap = False
        gap_reason = None
        if len(programs) > 1 and not self.model.get("call_graph") and flow_type not in ("SINGLE_IO",):
            gap = True
            gap_reason = (
                "MULTI_FILE_ARCHITECTURAL_GAP: multiple programs discovered with multi-file "
                "topology but no call-graph provided — generated Spring Batch topology may be incomplete"
            )

        return {
            "inputs": inputs,
            "outputs": outputs,
            "programs": programs,
            "flow_type": flow_type,
            "gap": gap,
            "gap_reason": gap_reason,
        }

