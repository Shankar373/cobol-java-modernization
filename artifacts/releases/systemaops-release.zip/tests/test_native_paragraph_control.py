import sys
import os
import subprocess
import tempfile
import shutil

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from modernize.lexer import CobolLexer
from modernize.parser import CobolParser
from modernize.native_generator import NativeProgramGenerator

def run_cobol_code(program_name: str, code: str) -> tuple:
    # Lex and parse
    filename = f"{program_name}.cob"
    lexer = CobolLexer(filename)
    tokens = lexer.tokenize(code)
    parser = CobolParser(tokens, filename)
    ir = parser.parse()
    
    # Generate native Java class source
    gen = NativeProgramGenerator(program_name, list(ir.nodes.values()))
    java_source = gen.generate_class_source()
    
    # Compile and execute Java
    temp_dir = tempfile.mkdtemp()
    try:
        pkg_dir = os.path.join(temp_dir, "com", "systema", "modernized", "native_gen")
        os.makedirs(pkg_dir, exist_ok=True)
        
        src_file = os.path.join(pkg_dir, f"{program_name.capitalize()}.java")
        with open(src_file, "w") as f:
            f.write(java_source)
            
        compile_res = subprocess.run(
            ["javac", src_file],
            capture_output=True,
            text=True
        )
        if compile_res.returncode != 0:
            raise Exception(f"Java compilation failed:\n{compile_res.stderr}")
            
        run_res = subprocess.run(
            ["java", "-cp", temp_dir, f"com.systema.modernized.native_gen.{program_name.capitalize()}"],
            capture_output=True,
            text=True
        )
        return run_res.returncode, run_res.stdout.strip().splitlines()
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

def test_natural_sequential_fallthrough_non_alpha():
    code = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. FALLTHRU.
        PROCEDURE DIVISION.
        Z-PARA.
            DISPLAY "Z".
        A-PARA.
            DISPLAY "A".
        M-PARA.
            DISPLAY "M".
    """
    code_val, output = run_cobol_code("FALLTHRU", code)
    assert code_val == 0
    assert output == ["Z", "A", "M"]

def test_perform_paragraph():
    code = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. PERFTEST.
        PROCEDURE DIVISION.
        MAIN-PARA.
            DISPLAY "START".
            PERFORM SUB-PARA.
            DISPLAY "END".
            STOP RUN.
        SUB-PARA.
            DISPLAY "SUB".
    """
    code_val, output = run_cobol_code("PERFTEST", code)
    assert code_val == 0
    assert output == ["START", "SUB", "END"]

def test_perform_thru_source_order():
    code = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. THRUTEST.
        PROCEDURE DIVISION.
        MAIN-PARA.
            PERFORM Z-PARA THRU M-PARA.
            STOP RUN.
        Z-PARA.
            DISPLAY "Z".
        A-PARA.
            DISPLAY "A".
        M-PARA.
            DISPLAY "M".
        OTHER-PARA.
            DISPLAY "O".
    """
    code_val, output = run_cobol_code("THRUTEST", code)
    assert code_val == 0
    assert output == ["Z", "A", "M"]

def test_nested_performs():
    code = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. NESTTEST.
        PROCEDURE DIVISION.
        MAIN-PARA.
            PERFORM OUTER-PARA.
            STOP RUN.
        OUTER-PARA.
            DISPLAY "OUTER-START".
            PERFORM INNER-PARA.
            DISPLAY "OUTER-END".
        INNER-PARA.
            DISPLAY "INNER".
    """
    code_val, output = run_cobol_code("NESTTEST", code)
    assert code_val == 0
    assert output == ["OUTER-START", "INNER", "OUTER-END"]

def test_stop_run_semantics():
    code = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. STOPTEST.
        PROCEDURE DIVISION.
        MAIN-PARA.
            DISPLAY "START".
            STOP RUN.
            DISPLAY "UNREACHABLE".
    """
    code_val, output = run_cobol_code("STOPTEST", code)
    assert code_val == 0
    assert output == ["START"]
